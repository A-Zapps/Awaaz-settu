package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioTtsManager
import com.example.audio.SpeechRecognizerHelper
import com.example.data.local.AppDatabase
import com.example.data.model.AppLanguage
import com.example.data.model.DocumentCategory
import com.example.data.model.DocumentItem
import com.example.data.model.GrievanceItem
import com.example.data.model.GrievanceStatus
import com.example.data.model.Scheme
import com.example.data.model.UserIntakeProfile
import com.example.data.repository.AwaazRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen {
    AUTH_LANGUAGE,
    USER_DETAILS_FORM,
    HOME,
    VOICE_INTAKE,
    SCHEME_RESULTS,
    GRIEVANCE_FORM,
    MY_DOCUMENTS,
    PROFILE,
    ADMIN_DASHBOARD
}

enum class UserRole {
    CITIZEN,
    ADMIN
}

data class IntakeStepData(
    val fieldName: String,
    val questionEn: String,
    val questionHi: String,
    val questionTe: String,
    val helperTextEn: String,
    val helperTextHi: String,
    val helperTextTe: String,
    val quickOptions: List<String>
)

class AwaazViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = AwaazRepository(database.appDao())
    val ttsManager = AudioTtsManager(application)
    val speechHelper = SpeechRecognizerHelper(application)
    private val prefs = application.getSharedPreferences("awaaz_setu_user_prefs", Context.MODE_PRIVATE)

    // App State - restore saved session if available
    private val _isAuthenticated = MutableStateFlow(prefs.getBoolean("is_authenticated", false))
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _userRole = MutableStateFlow(
        try {
            UserRole.valueOf(prefs.getString("user_role", UserRole.CITIZEN.name) ?: UserRole.CITIZEN.name)
        } catch (e: Exception) {
            UserRole.CITIZEN
        }
    )
    val userRole: StateFlow<UserRole> = _userRole.asStateFlow()

    private val _currentScreen = MutableStateFlow(
        if (prefs.getBoolean("is_authenticated", false)) {
            if (_userRole.value == UserRole.ADMIN) Screen.ADMIN_DASHBOARD else Screen.HOME
        } else {
            Screen.AUTH_LANGUAGE
        }
    )
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _userName = MutableStateFlow(prefs.getString("user_name", "Ramesh Rao") ?: "Ramesh Rao")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _userEmail = MutableStateFlow(prefs.getString("user_email", "ramesh.rao@gmail.com") ?: "ramesh.rao@gmail.com")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()


    // Connectivity & Offline Queue
    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _notificationBanner = MutableStateFlow<String?>(null)
    val notificationBanner: StateFlow<String?> = _notificationBanner.asStateFlow()

    // Reactive DB collections
    val allGrievances: StateFlow<List<GrievanceItem>> = repository.allGrievances
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDocuments: StateFlow<List<DocumentItem>> = repository.allDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _userProfile = MutableStateFlow(
        UserIntakeProfile(
            id = 1,
            isForSelf = true,
            beneficiaryName = "Ramesh Rao",
            age = 42,
            gender = "MALE",
            state = "Telangana",
            occupation = "",
            incomeRangeLakhs = 1.5,
            languageCode = "en"
        )
    )
    val userProfile: StateFlow<UserIntakeProfile> = _userProfile.asStateFlow()

    // Schemes State
    private val _matchedSchemes = MutableStateFlow<List<Scheme>>(emptyList())
    val matchedSchemes: StateFlow<List<Scheme>> = _matchedSchemes.asStateFlow()

    private val _selectedSchemeForGrievance = MutableStateFlow<Scheme?>(null)
    val selectedSchemeForGrievance: StateFlow<Scheme?> = _selectedSchemeForGrievance.asStateFlow()

    // 4-Field Step-by-Step Voice Intake State (Age, Gender, State, Income)
    val intakeSteps = listOf(
        IntakeStepData(
            fieldName = "Age",
            questionEn = "What is your age in years?",
            questionHi = "आपकी आयु कितने वर्ष है?",
            questionTe = "మీ వయస్సు ఎన్ని సంవత్సరాలు?",
            helperTextEn = "Speak your age clearly (e.g. 42)",
            helperTextHi = "अपनी आयु स्पष्ट बोलें (जैसे 42)",
            helperTextTe = "మీ వయస్సును స్పష్టంగా చెప్పండి (ఉదా. 42)",
            quickOptions = listOf("22", "35", "42", "58", "65")
        ),
        IntakeStepData(
            fieldName = "Gender",
            questionEn = "What is your gender?",
            questionHi = "आपका लिंग क्या है?",
            questionTe = "మీ లింగం ఏమిటి?",
            helperTextEn = "Speak Male, Female, or Other",
            helperTextHi = "पुरुष, महिला, या अन्य बोलें",
            helperTextTe = "పురుషుడు, స్త్రీ, లేదా ఇతరులు చెప్పండి",
            quickOptions = listOf("Male", "Female", "Other")
        ),
        IntakeStepData(
            fieldName = "State",
            questionEn = "Which state do you live in?",
            questionHi = "आप किस राज्य में रहते हैं?",
            questionTe = "మీరు ఏ రాష్ట్రంలో నివసిస్తున్నారు?",
            helperTextEn = "Speak your resident state (e.g. Telangana, Uttar Pradesh)",
            helperTextHi = "अपने राज्य का नाम बोलें (जैसे तेलंगाना, उत्तर प्रदेश)",
            helperTextTe = "మీ రాష్ట్రం పేరు చెప్పండి (ఉదా. తెలంగాణ)",
            quickOptions = listOf("Telangana", "Andhra Pradesh", "Uttar Pradesh", "Bihar", "Maharashtra")
        ),
        IntakeStepData(
            fieldName = "Income",
            questionEn = "What is your estimated annual family income?",
            questionHi = "आपकी वार्षिक पारिवारिक आय लगभग कितनी है?",
            questionTe = "మీ కుటుంబ వార్షిక ఆదాయం సుమారు ఎంత?",
            helperTextEn = "Speak your income range in Rupees",
            helperTextHi = "अपनी वार्षिक पारिवारिक आय बताएं",
            helperTextTe = "మీ వార్షిక ఆదాయాన్ని చెప్పండి",
            quickOptions = listOf("Below ₹1 Lakh", "₹1 - 2.5 Lakhs", "₹2.5 - 5 Lakhs", "Above ₹5 Lakhs")
        )
    )

    private val _currentIntakeStepIndex = MutableStateFlow(0)
    val currentIntakeStepIndex: StateFlow<Int> = _currentIntakeStepIndex.asStateFlow()

    // Temporary step answer buffer before confirmation
    private val _currentStepInputText = MutableStateFlow("")
    val currentStepInputText: StateFlow<String> = _currentStepInputText.asStateFlow()

    private val _currentStepConfirmed = MutableStateFlow(false)
    val currentStepConfirmed: StateFlow<Boolean> = _currentStepConfirmed.asStateFlow()

    // Collected intake answers in current flow
    private val _tempAge = MutableStateFlow(42)
    val tempAge: StateFlow<Int> = _tempAge.asStateFlow()

    private val _tempGender = MutableStateFlow("MALE")
    val tempGender: StateFlow<String> = _tempGender.asStateFlow()

    private val _tempState = MutableStateFlow("Telangana")
    val tempState: StateFlow<String> = _tempState.asStateFlow()

    private val _tempOccupation = MutableStateFlow("FARMER")
    val tempOccupation: StateFlow<String> = _tempOccupation.asStateFlow()

    private val _tempIncomeLakhs = MutableStateFlow(1.5)
    val tempIncomeLakhs: StateFlow<Double> = _tempIncomeLakhs.asStateFlow()

    private val _isWhoIsThisForSelf = MutableStateFlow(true)
    val isWhoIsThisForSelf: StateFlow<Boolean> = _isWhoIsThisForSelf.asStateFlow()

    private val _representativeCitizenName = MutableStateFlow("")
    val representativeCitizenName: StateFlow<String> = _representativeCitizenName.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            repository.userProfile.collect { profile ->
                if (profile != null) {
                    _userProfile.value = profile
                    _tempAge.value = profile.age
                    _tempGender.value = profile.gender
                    _tempState.value = profile.state
                    _tempOccupation.value = profile.occupation
                    _tempIncomeLakhs.value = profile.incomeRangeLakhs
                    _isWhoIsThisForSelf.value = profile.isForSelf
                    _representativeCitizenName.value = profile.beneficiaryName
                    _currentLanguage.value = AppLanguage.fromCode(profile.languageCode)
                    updateMatchedSchemes(profile)
                } else {
                    updateMatchedSchemes(_userProfile.value)
                }
            }
        }
    }

    private fun updateMatchedSchemes(profile: UserIntakeProfile) {
        _matchedSchemes.value = repository.getMatchedSchemes(profile)
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
        viewModelScope.launch {
            val updated = _userProfile.value.copy(languageCode = language.code)
            _userProfile.value = updated
            repository.saveUserProfile(updated)
        }
    }

    fun navigateTo(screen: Screen) {
        ttsManager.stop()
        speechHelper.stopListening()
        _currentScreen.value = screen
    }

    fun loginWithGoogle(
        role: UserRole = UserRole.CITIZEN,
        isForSelf: Boolean = true,
        beneficiary: String = "",
        googleName: String = "Ramesh Rao",
        googleEmail: String = "ramesh.rao@gmail.com"
    ) {
        _userRole.value = role
        _isWhoIsThisForSelf.value = isForSelf
        _userName.value = googleName.ifBlank { "Ramesh Rao" }
        _userEmail.value = googleEmail.ifBlank { "ramesh.rao@gmail.com" }
        _representativeCitizenName.value = if (isForSelf) _userName.value else beneficiary
        _isAuthenticated.value = true

        if (role == UserRole.ADMIN) {
            _userName.value = "District Welfare Officer"
            _userEmail.value = "officer.sangareddy@telangana.gov.in"
            prefs.edit()
                .putBoolean("is_authenticated", true)
                .putString("user_name", _userName.value)
                .putString("user_email", _userEmail.value)
                .putString("user_role", UserRole.ADMIN.name)
                .apply()
            navigateTo(Screen.ADMIN_DASHBOARD)
        } else {
            // Citizen Flow: Directs to details form before entering Welcome/Dashboard page
            navigateTo(Screen.USER_DETAILS_FORM)
        }
    }

    fun submitRegistrationForm(
        isForSelf: Boolean,
        beneficiaryName: String,
        phone: String,
        age: Int,
        gender: String,
        state: String,
        incomeRangeLakhs: Double,
        occupation: String = ""
    ) {
        viewModelScope.launch {
            val updatedProfile = UserIntakeProfile(
                id = 1,
                isForSelf = isForSelf,
                beneficiaryName = beneficiaryName.ifBlank { _userName.value },
                age = age.coerceIn(0, 115),
                gender = gender.uppercase(),
                state = state.ifBlank { "Telangana" },
                occupation = occupation.uppercase(),
                incomeRangeLakhs = incomeRangeLakhs,
                languageCode = _currentLanguage.value.code,
                lastUpdated = System.currentTimeMillis()
            )

            _userProfile.value = updatedProfile
            _tempAge.value = updatedProfile.age
            _tempGender.value = updatedProfile.gender
            _tempState.value = updatedProfile.state
            _tempOccupation.value = updatedProfile.occupation
            _tempIncomeLakhs.value = updatedProfile.incomeRangeLakhs
            _isWhoIsThisForSelf.value = isForSelf
            _representativeCitizenName.value = updatedProfile.beneficiaryName

            // Save to Room Database and session SharedPreferences
            repository.saveUserProfile(updatedProfile)
            updateMatchedSchemes(updatedProfile)

            prefs.edit()
                .putBoolean("is_authenticated", true)
                .putString("user_name", _userName.value)
                .putString("user_email", _userEmail.value)
                .putString("user_role", UserRole.CITIZEN.name)
                .apply()

            val welcomeMsg = when (_currentLanguage.value) {
                AppLanguage.HINDI -> "आवाज़ सेतु में आपका स्वागत है, ${updatedProfile.beneficiaryName}!"
                AppLanguage.TELUGU -> "ఆవాజ్ సేతుకి స్వాగతం, ${updatedProfile.beneficiaryName}!"
                AppLanguage.ENGLISH -> "Welcome to Awaaz Setu, ${updatedProfile.beneficiaryName}!"
            }
            _notificationBanner.value = welcomeMsg
            ttsManager.speak(welcomeMsg, _currentLanguage.value)

            // Direct to Welcome/Home page
            navigateTo(Screen.HOME)
        }
    }

    fun logout() {
        ttsManager.stop()
        speechHelper.stopListening()
        prefs.edit().clear().apply()
        _isAuthenticated.value = false
        _currentScreen.value = Screen.AUTH_LANGUAGE
    }


    // Voice Intake Flow Actions
    fun startVoiceIntake() {
        _currentIntakeStepIndex.value = 0
        _currentStepConfirmed.value = false
        loadStepInitialValue(0)
        navigateTo(Screen.VOICE_INTAKE)
    }

    private fun loadStepInitialValue(stepIndex: Int) {
        _currentStepInputText.value = when (stepIndex) {
            0 -> _tempAge.value.toString()
            1 -> when (_tempGender.value.uppercase()) {
                "FEMALE" -> "Female"
                "OTHER" -> "Other"
                else -> "Male"
            }
            2 -> _tempState.value
            3 -> when {
                _tempIncomeLakhs.value < 1.0 -> "Below ₹1 Lakh"
                _tempIncomeLakhs.value <= 2.5 -> "₹1 - 2.5 Lakhs"
                _tempIncomeLakhs.value <= 5.0 -> "₹2.5 - 5 Lakhs"
                else -> "Above ₹5 Lakhs"
            }
            else -> ""
        }
        _currentStepConfirmed.value = false
    }

    fun playCurrentStepPromptAudio() {
        val step = intakeSteps.getOrNull(_currentIntakeStepIndex.value) ?: return
        val text = when (_currentLanguage.value) {
            AppLanguage.HINDI -> "${step.questionHi}. ${step.helperTextHi}"
            AppLanguage.TELUGU -> "${step.questionTe}. ${step.helperTextTe}"
            AppLanguage.ENGLISH -> "${step.questionEn}. ${step.helperTextEn}"
        }
        ttsManager.speak(text, _currentLanguage.value, "intake_step_${_currentIntakeStepIndex.value}")
    }

    fun updateStepInput(text: String) {
        _currentStepInputText.value = text
        _currentStepConfirmed.value = false
    }

    fun startListeningForCurrentStep() {
        ttsManager.stop()
        speechHelper.startListening(_currentLanguage.value) { recognized ->
            _currentStepInputText.value = recognized
            _currentStepConfirmed.value = false
        }
    }

    fun speakUnderstoodValue(value: String) {
        val confirmPrompt = when (_currentLanguage.value) {
            AppLanguage.HINDI -> "हमने समझा: $value। क्या यह सही है?"
            AppLanguage.TELUGU -> "మేము అర్థం చేసుకున్నాము: $value. ఇది సరైనదేనా?"
            AppLanguage.ENGLISH -> "Understood: $value. Please confirm to proceed."
        }
        ttsManager.speak(confirmPrompt, _currentLanguage.value)
    }

    fun confirmAndProceedCurrentStep() {
        val stepIndex = _currentIntakeStepIndex.value
        val rawInput = _currentStepInputText.value.trim()

        // Apply raw input to the state
        when (stepIndex) {
            0 -> {
                val parsedAge = rawInput.filter { it.isDigit() }.toIntOrNull() ?: 42
                _tempAge.value = parsedAge.coerceIn(1, 120)
            }
            1 -> {
                _tempGender.value = when {
                    rawInput.contains("fem", ignoreCase = true) || rawInput.contains("महिला") || rawInput.contains("స్త్రీ") -> "FEMALE"
                    rawInput.contains("oth", ignoreCase = true) || rawInput.contains("अन्य") || rawInput.contains("ఇతర") -> "OTHER"
                    else -> "MALE"
                }
            }
            2 -> {
                _tempState.value = rawInput.ifBlank { "Telangana" }
            }
            3 -> {
                _tempIncomeLakhs.value = when {
                    rawInput.contains("below", ignoreCase = true) || rawInput.contains("कम") || rawInput.contains("తక్కువ") -> 0.8
                    rawInput.contains("2.5") -> 2.0
                    rawInput.contains("5") -> 3.5
                    else -> 1.5
                }
            }
        }

        if (stepIndex < intakeSteps.size - 1) {
            _currentIntakeStepIndex.value = stepIndex + 1
            loadStepInitialValue(stepIndex + 1)
        } else {
            // Finalize Intake
            finalizeIntake()
        }
    }

    fun previousIntakeStep() {
        val currentIndex = _currentIntakeStepIndex.value
        if (currentIndex > 0) {
            _currentIntakeStepIndex.value = currentIndex - 1
            loadStepInitialValue(currentIndex - 1)
        } else {
            navigateTo(Screen.HOME)
        }
    }

    fun finalizeIntake() {
        val updated = UserIntakeProfile(
            id = 1,
            isForSelf = _isWhoIsThisForSelf.value,
            beneficiaryName = _representativeCitizenName.value,
            age = _tempAge.value,
            gender = _tempGender.value,
            state = _tempState.value,
            occupation = _tempOccupation.value,
            incomeRangeLakhs = _tempIncomeLakhs.value,
            languageCode = _currentLanguage.value.code,
            lastUpdated = System.currentTimeMillis()
        )
        _userProfile.value = updated
        viewModelScope.launch {
            repository.saveUserProfile(updated)
            updateMatchedSchemes(updated)
            navigateTo(Screen.SCHEME_RESULTS)
        }
    }

    // TTS playback for scheme cards
    fun readSchemeCard(scheme: Scheme) {
        ttsManager.speak(scheme.getTtsScript(_currentLanguage.value), _currentLanguage.value, scheme.id)
    }

    // AI Generated Application Steps Map & Trigger
    private val _schemeStepsMap = MutableStateFlow<Map<String, String>>(emptyMap())
    val schemeStepsMap: StateFlow<Map<String, String>> = _schemeStepsMap.asStateFlow()

    private val _loadingStepsSchemeId = MutableStateFlow<String?>(null)
    val loadingStepsSchemeId: StateFlow<String?> = _loadingStepsSchemeId.asStateFlow()

    fun loadOrGenerateStepsForScheme(scheme: Scheme, forceRefresh: Boolean = false) {
        if (!forceRefresh && _schemeStepsMap.value.containsKey(scheme.id)) return
        viewModelScope.launch {
            _loadingStepsSchemeId.value = scheme.id
            val steps = com.example.data.ai.AiSchemeAdvisor.generateStepsToApply(
                scheme = scheme,
                language = _currentLanguage.value,
                profile = _userProfile.value
            )
            _schemeStepsMap.value = _schemeStepsMap.value + (scheme.id to steps)
            _loadingStepsSchemeId.value = null
        }
    }

    fun readStepsToApply(scheme: Scheme, stepsText: String) {
        ttsManager.speak(stepsText, _currentLanguage.value, "steps_${scheme.id}")
    }

    fun stopTts() {
        ttsManager.stop()
    }

    // Grievance Handling
    fun openGrievanceFormForScheme(scheme: Scheme?) {
        _selectedSchemeForGrievance.value = scheme
        navigateTo(Screen.GRIEVANCE_FORM)
    }

    fun submitGrievance(
        schemeId: String?,
        schemeName: String,
        category: String,
        description: String,
        isVoice: Boolean,
        citizenName: String,
        phone: String,
        state: String,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val item = repository.submitGrievance(
                schemeId = schemeId,
                schemeName = schemeName,
                category = category,
                description = description,
                isVoice = isVoice,
                citizenName = citizenName,
                citizenPhone = phone,
                state = state,
                isOnline = _isOnline.value
            )

            val msg = if (_isOnline.value) {
                "Grievance submitted successfully! Tracking ID: ${item.trackingNumber}"
            } else {
                "No connection. Saved to offline queue, will send when you're back online. Tracking ID: ${item.trackingNumber}"
            }
            _notificationBanner.value = msg

            // Voice confirmation
            val speech = when (_currentLanguage.value) {
                AppLanguage.HINDI -> "आपकी शिकायत दर्ज कर ली गई है। ट्रैकिंग नंबर ${item.trackingNumber} है।"
                AppLanguage.TELUGU -> "మీ ఫిర్యాదు నమోదు చేయబడింది. ట్రాకింగ్ నంబర్ ${item.trackingNumber}."
                AppLanguage.ENGLISH -> "Grievance registered. Your tracking ID is ${item.trackingNumber}."
            }
            ttsManager.speak(speech, _currentLanguage.value)
            onSuccess(item.trackingNumber)
        }
    }

    // Network Toggle & Offline Sync
    fun toggleNetworkOnline(online: Boolean) {
        _isOnline.value = online
        if (online) {
            viewModelScope.launch {
                repository.syncOfflineGrievances()
                _notificationBanner.value = "Back online. Offline submissions synchronized with server."
            }
        } else {
            _notificationBanner.value = "Offline Mode Enabled. Submissions will be safely queued locally."
        }
    }

    fun dismissBanner() {
        _notificationBanner.value = null
    }

    // Document Section Operations
    fun uploadDocument(title: String, category: DocumentCategory, fileName: String, sizeKb: Int) {
        viewModelScope.launch {
            repository.addDocument(title, category, fileName, sizeKb)
            val msg = when (_currentLanguage.value) {
                AppLanguage.HINDI -> "दस्तावेज़ सुरक्षित रूप से सहेजा गया।"
                AppLanguage.TELUGU -> "పత్రం సురక్షితంగా సేవ్ చేయబడింది."
                AppLanguage.ENGLISH -> "Document saved securely with encryption."
            }
            _notificationBanner.value = msg
        }
    }

    fun deleteDocument(id: Long) {
        viewModelScope.launch {
            repository.deleteDocument(id)
            _notificationBanner.value = "Document deleted permanently."
        }
    }

    // DPDP Act 2023 - Complete Citizen Data Deletion
    fun deleteMyData(onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.deleteMyData()
            prefs.edit().clear().apply()
            _isAuthenticated.value = false
            _currentScreen.value = Screen.AUTH_LANGUAGE
            _notificationBanner.value = "All your personal data, grievances, and documents have been permanently deleted per DPDP Act 2023."
            onComplete()
        }
    }

    // Admin Workbench Actions
    fun adminUpdateGrievanceStatus(id: Long, newStatus: GrievanceStatus, remarks: String) {
        viewModelScope.launch {
            repository.updateGrievanceStatusByAdmin(id, newStatus, remarks)
            _notificationBanner.value = "Status updated to ${newStatus.titleEn}. Push notification dispatched to citizen."
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        speechHelper.stopListening()
    }
}
