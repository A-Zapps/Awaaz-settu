package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicNone
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.ui.components.AwaazTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.ErrorBg
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SuccessBg
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen

@Composable
fun VoiceIntakeScreen(viewModel: AwaazViewModel) {
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val stepIndex by viewModel.currentIntakeStepIndex.collectAsStateWithLifecycle()
    val currentInputText by viewModel.currentStepInputText.collectAsStateWithLifecycle()
    val isListening by viewModel.speechHelper.isListening.collectAsStateWithLifecycle()
    val speechError by viewModel.speechHelper.errorMessage.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsStateWithLifecycle()

    val totalSteps = viewModel.intakeSteps.size
    val currentStep = viewModel.intakeSteps[stepIndex]
    val scrollState = rememberScrollState()

    val questionText = when (currentLang) {
        AppLanguage.HINDI -> currentStep.questionHi
        AppLanguage.TELUGU -> currentStep.questionTe
        AppLanguage.ENGLISH -> currentStep.questionEn
    }

    val helperText = when (currentLang) {
        AppLanguage.HINDI -> currentStep.helperTextHi
        AppLanguage.TELUGU -> currentStep.helperTextTe
        AppLanguage.ENGLISH -> currentStep.helperTextEn
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        AwaazTopBar(
            viewModel = viewModel,
            title = "Step ${stepIndex + 1} of $totalSteps",
            showBack = true,
            onBack = { viewModel.previousIntakeStep() }
        )

        // Step Progress Bar
        LinearProgressIndicator(
            progress = { (stepIndex + 1f) / totalSteps.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = BrandOrange,
            trackColor = BrandNavy.copy(alpha = 0.15f)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Field Header Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = BrandNavy.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = "Field: ${currentStep.fieldName}",
                        style = MaterialTheme.typography.labelMedium,
                        color = BrandNavy,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                // Audio Re-play Button
                IconButton(
                    onClick = { viewModel.playCurrentStepPromptAudio() },
                    modifier = Modifier
                        .size(44.dp)
                        .background(BrandOrange.copy(alpha = 0.12f), CircleShape)
                        .testTag("intake_audio_repeat_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Read question again",
                        tint = BrandOrange,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Question Card with Large Typography
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = questionText,
                        style = MaterialTheme.typography.headlineLarge,
                        color = BrandNavy,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = helperText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // STATIC MICROPHONE BUTTON (Section 5 UI/UX Design Doc)
            // No pulsing or animated ring. Clear static button with user language label!
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isListening) BrandOrange else BrandNavy
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (isListening) {
                            viewModel.speechHelper.stopListening()
                        } else {
                            viewModel.startListeningForCurrentStep()
                        }
                    }
                    .testTag("static_microphone_intake_button")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp, horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Hearing else Icons.Default.Mic,
                        contentDescription = "Microphone",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = if (isListening) {
                            when (currentLang) {
                                AppLanguage.HINDI -> "सुन रहे हैं... अभी बोलें"
                                AppLanguage.TELUGU -> "వింటున్నాము... మాట్లాడండి"
                                AppLanguage.ENGLISH -> "Listening... Speak now"
                            }
                        } else {
                            when (currentLang) {
                                AppLanguage.HINDI -> "अपना उत्तर बोलें (Speak Answer)"
                                AppLanguage.TELUGU -> "మీ సమాధానం మాట్లాడండి (Speak)"
                                AppLanguage.ENGLISH -> "Speak Your Answer"
                            }
                        },
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }
            }

            // Plain understood feedback statement & confirmation
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "ऐप ने समझा (Understood Answer):"
                            AppLanguage.TELUGU -> "యాప్ అర్థం చేసుకున్నది (Understood):"
                            AppLanguage.ENGLISH -> "What we understood:"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = BrandNavy,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Editable input field if transcription misread a number or state name
                    OutlinedTextField(
                        value = currentInputText,
                        onValueChange = { viewModel.updateStepInput(it) },
                        placeholder = { Text("Speak or type here...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("intake_step_input_field"),
                        textStyle = MaterialTheme.typography.headlineMedium.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandNavy,
                            unfocusedBorderColor = Color(0xFFD1D5DB)
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick option selection pills (for noisy environments or quick selection)
                    Text(
                        text = "Or tap a quick option:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        currentStep.quickOptions.take(3).forEach { option ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (currentInputText.equals(option, ignoreCase = true)) BrandNavy.copy(alpha = 0.15f) else LightCanvas,
                                border = BorderStroke(1.dp, Color(0xFFD1D5DB)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.updateStepInput(option)
                                        viewModel.speakUnderstoodValue(option)
                                    }
                            ) {
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = BrandNavy,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Speech recognizer warning/error if any
            if (speechError != null) {
                Surface(
                    color = ErrorBg,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = speechError ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ErrorRed,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // CONFIRM & PROCEED BUTTON (Section 5 UI/UX Doc - Confirm field by field before moving on!)
            Button(
                onClick = {
                    viewModel.confirmAndProceedCurrentStep()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandNavy,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("confirm_and_proceed_step_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (stepIndex == totalSteps - 1) {
                            when (currentLang) {
                                AppLanguage.HINDI -> "पुष्टि करें और योजनाएं देखें"
                                AppLanguage.TELUGU -> "నిర్ధారించి పథకాలు చూడండి"
                                AppLanguage.ENGLISH -> "Confirm & Find Schemes"
                            }
                        } else {
                            when (currentLang) {
                                AppLanguage.HINDI -> "सही है • अगला प्रश्न (Confirm & Next)"
                                AppLanguage.TELUGU -> "సరైనది • తర్వాతి ప్రశ్న"
                                AppLanguage.ENGLISH -> "Confirm & Next Step"
                            }
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Icon(
                        imageVector = if (stepIndex == totalSteps - 1) Icons.Default.Check else Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
