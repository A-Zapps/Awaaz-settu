package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

private val LogoNavy = Color(0xFF0D3B66)
private val LogoOrange = Color(0xFFF15A24)
private val LogoTaglineGray = Color(0xFF4B5563)

@Composable
fun AwaazTopBarLogo(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_awaaz_emblem_dynamic),
            contentDescription = "Awaaz Setu Logo",
            modifier = Modifier
                .width(44.dp)
                .height(34.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "AWAAZ",
                style = MaterialTheme.typography.titleSmall.copy(fontSize = 13.sp, lineHeight = 13.sp),
                color = LogoNavy,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Text(
                text = "SETU",
                style = MaterialTheme.typography.titleSmall.copy(fontSize = 13.sp, lineHeight = 13.sp),
                color = LogoOrange,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun AwaazLogoView(
    modifier: Modifier = Modifier,
    showTagline: Boolean = true,
    compact: Boolean = false
) {
    if (compact) {
        AwaazTopBarLogo(modifier = modifier)
    } else {
        Column(
            modifier = modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val emblemWidth = 160.dp
            val emblemHeight = 108.dp

            Image(
                painter = painterResource(id = R.drawable.ic_awaaz_emblem_dynamic),
                contentDescription = "Awaaz Setu Logo",
                modifier = Modifier.size(width = emblemWidth, height = emblemHeight),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Brand Title: "AWAAZ" in Navy on top, below it "SETU" in Orange
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "AWAAZ",
                    style = MaterialTheme.typography.headlineLarge,
                    color = LogoNavy,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "SETU",
                    style = MaterialTheme.typography.headlineLarge,
                    color = LogoOrange,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
            }

            if (showTagline) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Connecting Voices, Building Bridges",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.SansSerif,
                    color = LogoTaglineGray,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center,
                    letterSpacing = 0.4.sp
                )
            }
        }
    }
}


