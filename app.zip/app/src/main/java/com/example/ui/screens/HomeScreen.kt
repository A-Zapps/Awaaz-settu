package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.GrievanceStatus
import com.example.ui.components.AwaazLogoView
import com.example.ui.components.AwaazTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen

@Composable
fun HomeScreen(viewModel: AwaazViewModel) {
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val grievances by viewModel.allGrievances.collectAsStateWithLifecycle()
    val documents by viewModel.allDocuments.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        AwaazTopBar(
            viewModel = viewModel,
            showBack = false
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Welcome Header & Voice Greeting Button
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "नमस्ते, $userName"
                                AppLanguage.TELUGU -> "నమస్కారం, $userName"
                                AppLanguage.ENGLISH -> "Welcome, $userName"
                            },
                            style = MaterialTheme.typography.headlineMedium,
                            color = BrandNavy,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "सरकारी योजनाएं जानने के लिए नीचे बोलें"
                                AppLanguage.TELUGU -> "ప్రభుత్వ పథకాలను తెలుసుకోవడానికి క్రింద మాట్లాడండి"
                                AppLanguage.ENGLISH -> "Speak or check your eligible welfare schemes"
                            },
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextSecondary
                        )
                    }

                    IconButton(
                        onClick = {
                            val greeting = when (currentLang) {
                                AppLanguage.HINDI -> "नमस्ते $userName। आवाज़ सेतु में आपका स्वागत है। अपनी सरकारी योजनाएं खोजने के लिए 'मेरी योजनाएं खोजें' बटन दबाएं।"
                                AppLanguage.TELUGU -> "నమస్కారం $userName. ఆవాజ్ సేతుకు స్వాగతం. మీ ప్రభుత్వ పథకాలను కనుగొనడానికి 'నా పథకాలను కనుగొనండి' బటన్ నొక్కండి."
                                AppLanguage.ENGLISH -> "Welcome $userName to Awaaz Setu. Tap 'Find my schemes' to speak or discover your eligible government schemes."
                            }
                            viewModel.ttsManager.speak(greeting, currentLang)
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .background(BrandOrange.copy(alpha = 0.12f), CircleShape)
                            .testTag("home_audio_greeting_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen to instructions",
                            tint = BrandOrange,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            // PRIMARY HERO ACTION: "Find my schemes" (Section 3 & 4 UI/UX Design Doc)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BrandNavy),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.startVoiceIntake()
                    }
                    .testTag("find_my_schemes_hero_button")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BrandOrange,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Voice First • 5 Steps",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "मेरी सरकारी योजनाएं खोजें"
                            AppLanguage.TELUGU -> "నా ప్రభుత్వ పథకాలను కనుగొనండి"
                            AppLanguage.ENGLISH -> "Find My Government Schemes"
                        },
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "अपनी स्थिति बोलें और जानें कि आपको किन योजनाओं का लाभ मिलेगा"
                            AppLanguage.TELUGU -> "మీ వివరాలను మాట్లాడండి మరియు మీరు ఏ పథకాలకు అర్హులో తెలుసుకోండి"
                            AppLanguage.ENGLISH -> "Speak your details in your own language to get eligible schemes"
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White.copy(alpha = 0.9f)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { viewModel.startVoiceIntake() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrandOrange,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 54.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "शुरू करें (Speak Now)"
                                    AppLanguage.TELUGU -> "ప్రారంభించండి (Speak Now)"
                                    AppLanguage.ENGLISH -> "Start Scheme Search"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                    }
                }
            }

            // Quick Saved Profile Details Summary Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = BrandNavy,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "सहेजी गई जानकारी (Saved Intake)"
                                    AppLanguage.TELUGU -> "సేవ్ చేసిన వివరాలు"
                                    AppLanguage.ENGLISH -> "Saved Intake Profile"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = { viewModel.navigateTo(Screen.PROFILE) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Profile",
                                tint = BrandNavy
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Age: ${profile.age} yrs", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                            Text(text = "Gender: ${profile.gender}", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                        }
                        Column {
                            Text(text = "State: ${profile.state}", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                            Text(text = "Income: ₹${profile.incomeRangeLakhs}L/yr", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                        }
                    }
                }
            }

            // Quick Access 2-Column Grid: My Documents & Grievance Filing
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // "My Documents" Card (Section 8 UI/UX Design Doc)
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.navigateTo(Screen.MY_DOCUMENTS) }
                        .testTag("home_my_documents_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Surface(
                            shape = CircleShape,
                            color = BrandNavy.copy(alpha = 0.1f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.FolderShared,
                                    contentDescription = null,
                                    tint = BrandNavy,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "मेरे दस्तावेज़"
                                AppLanguage.TELUGU -> "నా పత్రాలు"
                                AppLanguage.ENGLISH -> "My Documents"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = BrandNavy,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "${documents.size} files • Stored safely",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }

                // Grievances Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.navigateTo(Screen.GRIEVANCE_FORM) }
                        .testTag("home_grievances_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Surface(
                            shape = CircleShape,
                            color = BrandOrange.copy(alpha = 0.12f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.ReportProblem,
                                    contentDescription = null,
                                    tint = BrandOrange,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "शिकायत दर्ज करें"
                                AppLanguage.TELUGU -> "ఫిర్యాదు చేయండి"
                                AppLanguage.ENGLISH -> "File Grievance"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = BrandNavy,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "${grievances.size} filed • Track status",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }

            // Grievances Live Status List (if any exist)
            if (grievances.isNotEmpty()) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "हाल की शिकायत स्थिति"
                                    AppLanguage.TELUGU -> "ఇటీవలి ఫిర్యాదుల స్థితి"
                                    AppLanguage.ENGLISH -> "Recent Grievance Status"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )

                            IconButton(
                                onClick = { viewModel.navigateTo(Screen.PROFILE) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "View All",
                                    tint = BrandNavy
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val latest = grievances.first()
                        val statusColor = when (latest.status) {
                            GrievanceStatus.RESOLVED -> SuccessGreen
                            GrievanceStatus.IN_PROGRESS -> BrandOrange
                            GrievanceStatus.UNDER_REVIEW -> WarningAmber
                            GrievanceStatus.SUBMITTED -> BrandNavy
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = latest.schemeName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "ID: ${latest.trackingNumber}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = statusColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = latest.status.getTitle(currentLang),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Trust Marker Footer
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Awaaz Setu • Woxsen University Pilot",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
