package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.DocumentCategory
import com.example.data.model.DocumentItem
import com.example.ui.components.AwaazTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen
import java.util.Locale

data class BenefitedSchemeSummary(
    val id: String,
    val schemeNameEn: String,
    val schemeNameHi: String,
    val schemeNameTe: String,
    val category: String,
    val benefitReceivedEn: String,
    val benefitReceivedHi: String,
    val benefitReceivedTe: String,
    val financialAmount: String,
    val status: String,
    val dateTakenPlace: String,
    val transactionRef: String,
    val linkedDocuments: List<String>
)

@Composable
fun DocumentsScreen(viewModel: AwaazViewModel) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val documents by viewModel.allDocuments.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showUploadModal by remember { mutableStateOf(false) }
    var newDocTitle by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(DocumentCategory.IDENTITY_PROOF) }
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedFileSizeKb by remember { mutableIntStateOf(350) }

    // System File Picker Launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            var fileName = "device_document_${System.currentTimeMillis()}.pdf"
            var fileSize = 380
            try {
                val cursor = context.contentResolver.query(uri, null, null, null, null)
                cursor?.use {
                    if (it.moveToFirst()) {
                        val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                        if (nameIndex != -1) {
                            val resolved = it.getString(nameIndex)
                            if (!resolved.isNullOrBlank()) fileName = resolved
                        }
                        if (sizeIndex != -1) {
                            val sizeBytes = it.getLong(sizeIndex)
                            if (sizeBytes > 0) {
                                fileSize = (sizeBytes / 1024).toInt().coerceAtLeast(1)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                fileName = uri.lastPathSegment ?: "document_${System.currentTimeMillis()}.pdf"
            }

            selectedFileUri = uri
            selectedFileName = fileName
            selectedFileSizeKb = fileSize
            if (newDocTitle.isBlank()) {
                val cleanName = fileName.substringBeforeLast(".")
                    .replace("_", " ")
                    .replace("-", " ")
                    .trim()
                newDocTitle = cleanName.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            }
            showUploadModal = true
        }
    }

    // Historical list of Schemes Taken Place / Benefited
    val benefitedSchemes = remember {
        listOf(
            BenefitedSchemeSummary(
                id = "pm_kisan",
                schemeNameEn = "PM-KISAN Samman Nidhi",
                schemeNameHi = "पीएम किसान सम्मान निधि",
                schemeNameTe = "పీఎం కిసాన్ సమ్మాన్ నిధి",
                category = "Agriculture",
                benefitReceivedEn = "Direct DBT Income Support (₹6,000/yr). 16th Installment Credited.",
                benefitReceivedHi = "प्रत्यक्ष डीबीटी वित्तीय सहायता (₹6,000/वर्ष)। 16वीं किस्त जमा।",
                benefitReceivedTe = "ప్రత్యక్ష డీబీటీ ఆదాయ సహాయం (రూ. 6,000/ఏటా). 16వ విడత జమ అయింది.",
                financialAmount = "₹16,000 Total Disbursed",
                status = "Active & Disbursed",
                dateTakenPlace = "28 Aug 2024",
                transactionRef = "DBT-UTR# 908124892110 (SBI •••• 4821)",
                linkedDocuments = listOf("Aadhaar e-KYC", "Bank Passbook", "Pattadar Passbook")
            ),
            BenefitedSchemeSummary(
                id = "rythu_bharosa",
                schemeNameEn = "Rythu Bharosa / Rythu Bandhu",
                schemeNameHi = "रैतु भरोसा (तेलंगाना)",
                schemeNameTe = "రైతు భరోసా / రైతు బంధు (తెలంగాణ)",
                category = "Agriculture",
                benefitReceivedEn = "Agricultural Investment Support for 1.5 Acres land.",
                benefitReceivedHi = "1.5 एकड़ भूमि के लिए कृषि निवेश सहायता।",
                benefitReceivedTe = "1.5 ఎకరాల సాగు భూమి కొరకు వ్యవసాయ పెట్టుబడి సహాయం.",
                financialAmount = "₹15,000 Received (Kharif/Rabi)",
                status = "Sanctioned & Credited",
                dateTakenPlace = "14 Jan 2024",
                transactionRef = "TS-AGR-RB-88329 (Sangareddy Dist)",
                linkedDocuments = listOf("Land Record (Pahani)", "Aadhaar Card")
            ),
            BenefitedSchemeSummary(
                id = "ayushman_bharat",
                schemeNameEn = "Ayushman Bharat PM-JAY",
                schemeNameHi = "आयुष्मान भारत प्रधानमंत्री जन आरोग्य योजना",
                schemeNameTe = "ఆయుష్మాన్ భారత్ పీఎం-జేఏవై",
                category = "Healthcare",
                benefitReceivedEn = "Cashless Family Hospitalization Health Cover up to ₹5 Lakhs.",
                benefitReceivedHi = "₹5,00,000 तक का मुफ्त कैशलेस पारिवारिक स्वास्थ्य बीमा।",
                benefitReceivedTe = "కుటుంబానికి ₹5,00,000 వరకు ఉచిత క్యాష్‌లెస్ ఆరోగ్య బీమా.",
                financialAmount = "₹5,00,000 Active Family Cover",
                status = "Golden Card Issued",
                dateTakenPlace = "10 Oct 2023",
                transactionRef = "ABHA-ID# 91-4820-1928-3310",
                linkedDocuments = listOf("NFSA Pink Ration Card", "Income Certificate")
            ),
            BenefitedSchemeSummary(
                id = "pm_ujjwala",
                schemeNameEn = "PM Ujjwala Yojana 2.0",
                schemeNameHi = "प्रधानमंत्री उज्ज्वला योजना 2.0",
                schemeNameTe = "ప్రధానమంత్రి ఉజ్జ్వల యోజన 2.0",
                category = "Social Welfare",
                benefitReceivedEn = "Free LPG Connection, Stove & ₹300 Monthly Refill Subsidy.",
                benefitReceivedHi = "मुफ्त एलपीजी कनेक्शन, चूल्हा व ₹300 मासिक रिफिल सब्सिडी।",
                benefitReceivedTe = "ఉచిత గ్యాస్ కనెక్షన్, పొయ్యి మరియు ₹300 నెలవారీ రీఫిల్ సబ్సిడీ.",
                financialAmount = "₹1,600 + Refill Subsidies",
                status = "Connection Availed",
                dateTakenPlace = "05 Mar 2023",
                transactionRef = "INDANE-LPG# 78190214",
                linkedDocuments = listOf("Ration Card", "Identity Proof")
            ),
            BenefitedSchemeSummary(
                id = "mgnrega",
                schemeNameEn = "MGNREGA Rural Employment Guarantee",
                schemeNameHi = "मनरेगा ग्रामीण रोजगार गारंटी",
                schemeNameTe = "మహాత్మా గాంధీ గ్రామీణ ఉపాధి హామీ పథకం",
                category = "Employment",
                benefitReceivedEn = "Guaranteed 100 Days Wage Employment (52 Days Completed).",
                benefitReceivedHi = "100 दिन का गारंटीकृत रोजगार (52 दिन पूर्ण)।",
                benefitReceivedTe = "100 రోజుల హామీ వేతన ఉపాధి (52 రోజులు పూర్తయ్యాయి).",
                financialAmount = "₹14,200 Direct Wages Paid",
                status = "Job Card Active",
                dateTakenPlace = "Fiscal Year 2024-25",
                transactionRef = "TS-SANGAREDDY-JC-4901",
                linkedDocuments = listOf("Gram Panchayat Job Card", "Bank Account")
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        AwaazTopBar(
            viewModel = viewModel,
            title = when (currentLang) {
                AppLanguage.HINDI -> "दस्तावेज़ और योजना सारांश"
                AppLanguage.TELUGU -> "పత్రాలు & పథకాల సారాంశం"
                AppLanguage.ENGLISH -> "Documents & Schemes Summary"
            },
            showBack = true,
            onBack = { viewModel.navigateTo(Screen.HOME) }
        )

        // Top Navigation Tabs: My Documents vs Schemes Summary
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.White,
            contentColor = BrandNavy,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = BrandNavy,
                    height = 3.dp
                )
            }
        ) {
            Tab(
                selected = selectedTabIndex == 0,
                onClick = { selectedTabIndex = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FolderShared,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "मेरे दस्तावेज़ (${documents.size})"
                                AppLanguage.TELUGU -> "నా పత్రాలు (${documents.size})"
                                AppLanguage.ENGLISH -> "My Documents (${documents.size})"
                            },
                            fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                }
            )

            Tab(
                selected = selectedTabIndex == 1,
                onClick = { selectedTabIndex = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Assessment,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "योजना सारांश (5)"
                                AppLanguage.TELUGU -> "పథకాల సారాంశం (5)"
                                AppLanguage.ENGLISH -> "Schemes Summary (5)"
                            },
                            fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                }
            )
        }

        if (selectedTabIndex == 0) {
            // TAB 1: MY DOCUMENTS VAULT & DEVICE UPLOAD
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Mandatory Clear Privacy Banner (DPDP Act 2023)
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = BrandNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Encrypted",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = when (currentLang) {
                                        AppLanguage.HINDI -> "केवल आप ही इन दस्तावेज़ों को देख सकते हैं।"
                                        AppLanguage.TELUGU -> "మీరు మాత్రమే ఈ పత్రాలను చూడగలరు."
                                        AppLanguage.ENGLISH -> "Only you can access these documents."
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "AES-256 encrypted local storage per India DPDP Act 2023.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 11.5.sp
                                )
                            }
                        }
                    }
                }

                // Add Document From Device Primary Section
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = BorderStroke(1.5.dp, Color(0xFFE2DCE8)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "डिवाइस से दस्तावेज़ जोड़ें"
                                    AppLanguage.TELUGU -> "పరికరం నుండి పత్రాన్ని జోడించండి"
                                    AppLanguage.ENGLISH -> "Add File From Device"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Upload Aadhaar, Ration Card, Land Records (7/12), Income Certificate or Passbook directly from your phone.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Primary Button: Pick from Device
                                Button(
                                    onClick = {
                                        filePickerLauncher.launch("*/*")
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = BrandNavy,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("btn_choose_file_device")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.AttachFile,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = when (currentLang) {
                                                AppLanguage.HINDI -> "फ़ाइल चुनें"
                                                AppLanguage.TELUGU -> "ఫైల్ ఎంచుకోండి"
                                                AppLanguage.ENGLISH -> "Choose File"
                                            },
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }

                                // Secondary Button: Manual / Custom Add
                                OutlinedButton(
                                    onClick = {
                                        selectedFileName = ""
                                        selectedFileUri = null
                                        newDocTitle = ""
                                        showUploadModal = true
                                    },
                                    border = BorderStroke(1.dp, BrandNavy),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("btn_manual_add_doc")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = null,
                                            tint = BrandNavy,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = when (currentLang) {
                                                AppLanguage.HINDI -> "मैन्युअल नाम"
                                                AppLanguage.TELUGU -> "పేరు నమోదు"
                                                AppLanguage.ENGLISH -> "Manual Entry"
                                            },
                                            color = BrandNavy,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Upload & Details Modal/Form Card
                if (showUploadModal) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            border = BorderStroke(1.5.dp, BrandOrange),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Save Document Securely",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = BrandNavy,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = BrandOrange.copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "AES-256 Protected",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = BrandOrange,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                if (selectedFileName.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFF1F5F9),
                                        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = SuccessGreen,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Selected from device:",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = TextSecondary
                                                )
                                                Text(
                                                    text = "$selectedFileName ($selectedFileSizeKb KB)",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF0F172A)
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                val solidBlack = Color(0xFF0F172A)
                                OutlinedTextField(
                                    value = newDocTitle,
                                    onValueChange = { newDocTitle = it },
                                    label = { Text("Document Title (e.g. Aadhaar Card, Land Record 7/12)") },
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                                        color = solidBlack,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = solidBlack,
                                        unfocusedTextColor = solidBlack,
                                        focusedBorderColor = BrandNavy,
                                        unfocusedBorderColor = Color(0xFF94A3B8),
                                        focusedLabelColor = BrandNavy,
                                        unfocusedLabelColor = Color(0xFF475569),
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "Select Document Category:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                DocumentCategory.entries.forEach { cat ->
                                    val isSelected = selectedCategory == cat
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isSelected) BrandNavy.copy(alpha = 0.12f) else LightCanvas,
                                        border = BorderStroke(1.dp, if (isSelected) BrandNavy else Color(0xFFD1D5DB)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                            .clickable { selectedCategory = cat }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            if (isSelected) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = BrandNavy,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                            }
                                            Text(
                                                text = cat.getTitle(currentLang),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = if (isSelected) BrandNavy else TextPrimary,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            showUploadModal = false
                                            selectedFileName = ""
                                            selectedFileUri = null
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Cancel")
                                    }

                                    Button(
                                        onClick = {
                                            val title = newDocTitle.ifBlank {
                                                if (selectedFileName.isNotBlank()) selectedFileName.substringBeforeLast(".") else "Identity Document"
                                            }
                                            val finalFileName = if (selectedFileName.isNotBlank()) selectedFileName else "${title.lowercase().replace(" ", "_")}.pdf"
                                            viewModel.uploadDocument(title, selectedCategory, finalFileName, selectedFileSizeKb)
                                            newDocTitle = ""
                                            selectedFileName = ""
                                            selectedFileUri = null
                                            showUploadModal = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Save to Vault", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }



                // Documents Vault Heading
                item {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "सहेजे गए दस्तावेज़ (${documents.size})"
                            AppLanguage.TELUGU -> "భద్రపరిచిన పత్రాలు (${documents.size})"
                            AppLanguage.ENGLISH -> "Saved Vault Documents (${documents.size})"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = BrandNavy
                    )
                }

                // Documents List
                items(documents, key = { it.id }) { doc ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = BrandNavy.copy(alpha = 0.1f),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = null,
                                        tint = BrandNavy,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = doc.title,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${doc.category.getTitle(currentLang)} • ${doc.fileSizeKb} KB • ${doc.uploadDate}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    fontSize = 11.5.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFEF3C7)
                                ) {
                                    Text(
                                        text = "Retained for ${doc.retentionDaysRemaining} days (Encrypted)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF92400E),
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = { viewModel.deleteDocument(doc.id) },
                                modifier = Modifier.testTag("delete_doc_${doc.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete Document",
                                    tint = ErrorRed,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        } else {
            // TAB 2: SCHEMES SUMMARY (SUMMARY OF SCHEMES THAT HAVE TAKEN PLACE)
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top KPI Summary Cards Banner
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = BrandNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text(
                                        text = when (currentLang) {
                                            AppLanguage.HINDI -> "योजना लाभार्थी सारांश"
                                            AppLanguage.TELUGU -> "పథకాల లబ్ధిదారు సారాంశం"
                                            AppLanguage.ENGLISH -> "Citizen Welfare & Schemes Summary"
                                        },
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Beneficiary: ${profile.beneficiaryName.ifBlank { "Ramesh Rao" }} (${profile.state})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 12.sp
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SuccessGreen.copy(alpha = 0.35f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Verified,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "e-KYC Verified",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Grid of KPI Stats
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White.copy(alpha = 0.12f),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "Schemes Availed",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                        Text(
                                            text = "${benefitedSchemes.size} Schemes",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White.copy(alpha = 0.12f),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "Total DBT Disbursed",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                        Text(
                                            text = "₹45,200+",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color(0xFFFDE047),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MedicalServices,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Health & Social Security:",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                        Text(
                                            text = "₹5,00,000 Ayushman Bharat Cover + Free LPG",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Download/Save Welfare Statement Button
                item {
                    Button(
                        onClick = {
                            viewModel.uploadDocument(
                                title = "Official Citizen Welfare & Scheme Summary Statement (2024-2026)",
                                category = DocumentCategory.APPLICATION_SUMMARY,
                                fileName = "citizen_schemes_summary_${System.currentTimeMillis()}.pdf",
                                sizeKb = 450
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "योजना सारांश प्रमाणपत्र डाउनलोड / सेव करें (PDF)"
                                    AppLanguage.TELUGU -> "పథకాల సారాంశ ధృవీకరణ పత్రం డౌన్‌లోడ్ చేయండి (PDF)"
                                    AppLanguage.ENGLISH -> "Save Official Scheme Summary PDF to Vault"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                // Section Title: Detailed Schemes that took place
                item {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "सक्रिय और लाभान्वित योजनाओं का विवरण"
                            AppLanguage.TELUGU -> "అమలవుతున్న మరియు లబ్ధి పొందిన పథకాల వివరాలు"
                            AppLanguage.ENGLISH -> "Schemes Availed & Benefited History"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = BrandNavy
                    )
                }

                // Cards for Each Benefited Scheme
                items(benefitedSchemes, key = { it.id }) { item ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header Row with Category & Status Badge
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = when (item.category) {
                                            "Agriculture" -> SuccessGreen.copy(alpha = 0.12f)
                                            "Healthcare" -> InfoBlue.copy(alpha = 0.12f)
                                            else -> BrandOrange.copy(alpha = 0.12f)
                                        },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = when (item.category) {
                                                    "Agriculture" -> Icons.Default.CurrencyRupee
                                                    "Healthcare" -> Icons.Default.HealthAndSafety
                                                    "Employment" -> Icons.Default.Work
                                                    else -> Icons.Default.ReceiptLong
                                                },
                                                contentDescription = null,
                                                tint = when (item.category) {
                                                    "Agriculture" -> SuccessGreen
                                                    "Healthcare" -> InfoBlue
                                                    else -> BrandOrange
                                                },
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = item.category,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TextSecondary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SuccessGreen.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.3f))
                                ) {
                                    Text(
                                        text = item.status,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SuccessGreen,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Scheme Name
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> item.schemeNameHi
                                    AppLanguage.TELUGU -> item.schemeNameTe
                                    AppLanguage.ENGLISH -> item.schemeNameEn
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Benefit Received
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> item.benefitReceivedHi
                                    AppLanguage.TELUGU -> item.benefitReceivedTe
                                    AppLanguage.ENGLISH -> item.benefitReceivedEn
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                fontSize = 13.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                            Spacer(modifier = Modifier.height(8.dp))

                            // Financial Aid & Timeline Details
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Sanctioned Benefit:",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = item.financialAmount,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = BrandNavy
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Disbursement Date:",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = item.dateTakenPlace,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Transaction / Beneficiary Ref
                            Text(
                                text = "Ref / Account: ${item.transactionRef}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF64748B),
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Linked Proofs & Documents
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Linked:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                                item.linkedDocuments.forEach { docName ->
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFFF1F5F9)
                                    ) {
                                        Text(
                                            text = docName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF334155),
                                            fontSize = 10.5.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
