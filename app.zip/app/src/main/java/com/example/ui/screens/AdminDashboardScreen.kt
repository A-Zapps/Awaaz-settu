package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.GrievanceItem
import com.example.data.model.GrievanceStatus
import com.example.ui.components.AwaazTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandNavyDark
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminDashboardScreen(viewModel: AwaazViewModel) {
    val grievances by viewModel.allGrievances.collectAsStateWithLifecycle()
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()

    var editingGrievanceId by remember { mutableStateOf<Long?>(null) }
    var selectedStatus by remember { mutableStateOf(GrievanceStatus.IN_PROGRESS) }
    var officerRemarksText by remember { mutableStateOf("") }

    val pendingCount = grievances.count { it.status == GrievanceStatus.SUBMITTED }
    val inProgressCount = grievances.count { it.status == GrievanceStatus.IN_PROGRESS || it.status == GrievanceStatus.UNDER_REVIEW }
    val resolvedCount = grievances.count { it.status == GrievanceStatus.RESOLVED }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        AwaazTopBar(
            viewModel = viewModel,
            title = "District Officer Workbench",
            showBack = true,
            onBack = { viewModel.navigateTo(Screen.AUTH_LANGUAGE) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header stats
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandNavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Sangareddy District Portal",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Welfare Redressal Officer: D. Srinivas",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }

                            IconButton(
                                onClick = { viewModel.logout() },
                                modifier = Modifier.testTag("admin_logout_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = "Exit Admin",
                                    tint = BrandOrange
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // 3 Stats Metrics
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(text = "$pendingCount", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                    Text(text = "Pending", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(text = "$inProgressCount", style = MaterialTheme.typography.headlineMedium, color = BrandOrange, fontWeight = FontWeight.Bold)
                                    Text(text = "In Review", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(text = "$resolvedCount", style = MaterialTheme.typography.headlineMedium, color = SuccessGreen, fontWeight = FontWeight.Bold)
                                    Text(text = "Resolved", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                                }
                            }
                        }
                    }
                }
            }

            // Grievances List to resolve
            item {
                Text(
                    text = "Active Citizen Grievances (${grievances.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandNavy,
                    fontWeight = FontWeight.Bold
                )
            }

            items(grievances, key = { it.id }) { item ->
                val isEditing = editingGrievanceId == item.id
                val statusColor = when (item.status) {
                    GrievanceStatus.RESOLVED -> SuccessGreen
                    GrievanceStatus.IN_PROGRESS -> BrandOrange
                    GrievanceStatus.UNDER_REVIEW -> WarningAmber
                    GrievanceStatus.SUBMITTED -> BrandNavy
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = item.trackingNumber,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = BrandNavy,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${item.citizenName} • Tel: ${item.citizenPhone}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = statusColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = item.status.titleEn,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Scheme: ${item.schemeName} (${item.category})",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = LightCanvas,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                modifier = Modifier.padding(10.dp)
                            )
                        }

                        if (item.officerRemarks.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Current Remarks: ${item.officerRemarks}",
                                style = MaterialTheme.typography.bodySmall,
                                color = BrandNavy,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (!isEditing) {
                            Button(
                                onClick = {
                                    editingGrievanceId = item.id
                                    selectedStatus = item.status
                                    officerRemarksText = item.officerRemarks
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandNavy),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Update Status & Resolution Remarks")
                                }
                            }
                        } else {
                            // Status Editor
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(BrandNavy.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "Select New Status:",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BrandNavy
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    GrievanceStatus.entries.forEach { status ->
                                        val isSel = selectedStatus == status
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isSel) BrandNavy else Color.White,
                                            border = BorderStroke(1.dp, if (isSel) BrandNavy else Color(0xFFD1D5DB)),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { selectedStatus = status }
                                        ) {
                                            Text(
                                                text = status.titleEn,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isSel) Color.White else TextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp),
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = officerRemarksText,
                                    onValueChange = { officerRemarksText = it },
                                    label = { Text("Resolution / Officer Action Remarks") },
                                    placeholder = { Text("e.g. Bank IFSC verified, installment processed via Treasury...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = false
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { editingGrievanceId = null },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Cancel")
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.adminUpdateGrievanceStatus(
                                                id = item.id,
                                                newStatus = selectedStatus,
                                                remarks = officerRemarksText.ifBlank { "Updated by Nodal Redressal Officer." }
                                            )
                                            editingGrievanceId = null
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Save & Notify")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
