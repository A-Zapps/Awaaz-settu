package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AwaazLightColorScheme = lightColorScheme(
    primary = BrandNavy,
    onPrimary = Color.White,
    primaryContainer = BrandNavyDark,
    onPrimaryContainer = Color.White,
    secondary = BrandOrange,
    onSecondary = Color.White,
    secondaryContainer = BrandOrangeLight,
    onSecondaryContainer = BrandOrange,
    tertiary = BrandOrange,
    onTertiary = Color.White,
    background = LightCanvas,
    onBackground = TextPrimary,
    surface = SurfaceCard,
    onSurface = TextPrimary,
    surfaceVariant = LightCanvas,
    onSurfaceVariant = TextSecondary,
    outline = BorderStroke,
    outlineVariant = BorderStroke.copy(alpha = 0.5f)
)

private val AwaazDarkColorScheme = darkColorScheme(
    primary = Color(0xFF93C5FD),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = BrandNavy,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFFB923C),
    onSecondary = Color(0xFF0F172A),
    background = Color(0xFF0B1320),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF131F33),
    onSurface = Color(0xFFF8FAFC),
    outline = Color(0xFF334155)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    // Standard high-contrast citizen theme for clarity across all light/dark system settings
    val colorScheme = if (darkTheme) AwaazDarkColorScheme else AwaazLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

