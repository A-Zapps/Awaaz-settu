package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.ui.components.AwaazTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.ErrorBg
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen

@Composable
fun ProfileScreen(viewModel: AwaazViewModel) {
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val userEmail by viewModel.userEmail.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val grievances by viewModel.allGrievances.collectAsStateWithLifecycle()
    val documents by viewModel.allDocuments.collectAsStateWithLifecycle()

    var showDeleteDataDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        AwaazTopBar(
            viewModel = viewModel,
            title = when (currentLang) {
                AppLanguage.HINDI -> "मेरी प्रोफ़ाइल"
                AppLanguage.TELUGU -> "నా ప్రొఫైల్"
                AppLanguage.ENGLISH -> "My Profile & Settings"
            },
            showBack = true,
            onBack = { viewModel.navigateTo(Screen.HOME) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Google Account Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BrandNavy,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = userName,
                                style = MaterialTheme.typography.titleLarge,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = userEmail,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (profile.isForSelf) "Self Filing Account" else "Filing for: ${profile.beneficiaryName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = BrandOrange,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        IconButton(
                            onClick = { viewModel.logout() },
                            modifier = Modifier.testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = "Log out",
                                tint = ErrorRed
                            )
                        }
                    }
                }
            }

            // Saved Voice Intake Profile & Fast Edit Shortcut
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "सहेजी गई पात्रता जानकारी"
                                    AppLanguage.TELUGU -> "సేవ్ చేసిన అర్హత వివరాలు"
                                    AppLanguage.ENGLISH -> "Saved Eligibility Answers"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )

                            Button(
                                onClick = { viewModel.startVoiceIntake() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandNavy.copy(alpha = 0.1f),
                                    contentColor = BrandNavy
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Edit Answers", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "Age: ${profile.age} Years", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "Gender: ${profile.gender}", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "State: ${profile.state}", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "Income: ₹${profile.incomeRangeLakhs} Lakhs/yr", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                            }
                        }
                    }
                }
            }

            // Quick Navigation shortcuts
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.navigateTo(Screen.MY_DOCUMENTS) }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.FolderShared, contentDescription = null, tint = BrandNavy)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "My Documents (${documents.size} stored)",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        HorizontalDivider(color = Color(0xFFF3F4F6))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.navigateTo(Screen.GRIEVANCE_FORM) }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.ReportProblem, contentDescription = null, tint = BrandOrange)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "My Grievances (${grievances.size} filed)",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Legal & DPDP Compliance Banner
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = BrandNavy,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Digital Personal Data Protection Act 2023",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Awaaz Setu processes voice inputs and documents locally on your device or via secure encrypted government channels. You retain full control to erase all your data at any time.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // SECTION 9 UI/UX DOC: "DELETE MY DATA" BUTTON
                        OutlinedButton(
                            onClick = { showDeleteDataDialog = true },
                            border = BorderStroke(1.5.dp, ErrorRed),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("delete_my_data_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.DeleteForever,
                                    contentDescription = null,
                                    tint = ErrorRed,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Delete My Data (डेटा हटाएं)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Dedicated Account Logout Button
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "खाता सत्र प्रबंधन"
                                AppLanguage.TELUGU -> "ఖాతా నిర్వహణ"
                                AppLanguage.ENGLISH -> "Account Session"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BrandNavy
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "इस डिवाइस से सुरक्षित रूप से लॉग आउट करें।"
                                AppLanguage.TELUGU -> "ఈ పరికరం నుండి సురక్షితంగా లాగ్ అవుట్ చేయండి."
                                AppLanguage.ENGLISH -> "Sign out securely from this device."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showLogoutDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFFF1F2),
                                contentColor = ErrorRed
                            ),
                            border = BorderStroke(1.5.dp, Color(0xFFFDA4AF)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("profile_logout_action_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = null,
                                    tint = ErrorRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = when (currentLang) {
                                        AppLanguage.HINDI -> "खाते से लॉग आउट करें (Log Out)"
                                        AppLanguage.TELUGU -> "ఖాతా నుండి లాగ్ అవుట్ చేయండి (Log Out)"
                                        AppLanguage.ENGLISH -> "Log Out of Account"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ErrorRed
                                )
                            }
                        }
                    }
                }
            }

            // Academic Attribution Footer
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Awaaz Setu • Version 0.2 Pilot\nWoxsen University • Owner: Sai Rapelly",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // LOGOUT CONFIRMATION DIALOG
        if (showLogoutDialog) {
            AlertDialog(
                onDismissRequest = { showLogoutDialog = false },
                title = {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "लॉग आउट की पुष्टि करें"
                            AppLanguage.TELUGU -> "లాగ్ అవుట్ నిర్ధారించండి"
                            AppLanguage.ENGLISH -> "Log Out of Account?"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = BrandNavy
                    )
                },
                text = {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "क्या आप निश्चित रूप से अपने खाते से लॉग आउट करना चाहते हैं?"
                            AppLanguage.TELUGU -> "మీరు ఖచ్చితంగా మీ ఖాతా నుండి లాగ్ అవుట్ చేయాలనుకుంటున్నారా?"
                            AppLanguage.ENGLISH -> "Are you sure you want to log out from this device? You can sign back in at any time."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showLogoutDialog = false
                            viewModel.logout()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                    ) {
                        Text("Log Out", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showLogoutDialog = false }) {
                        Text("Cancel", color = TextPrimary)
                    }
                }
            )
        }

        // DPDP Act 2023 MANDATORY CONFIRMATION DIALOG (Section 9 UI/UX Design Doc)
        if (showDeleteDataDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDataDialog = false },
                title = {
                    Text(
                        text = "Permanently Delete All Data?",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = ErrorRed
                    )
                },
                text = {
                    Text(
                        text = "This will delete your saved answers, your uploaded documents, and your grievance history from this device and our servers. This cannot be undone.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showDeleteDataDialog = false
                            viewModel.deleteMyData {}
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                    ) {
                        Text("Delete Everything", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDataDialog = false }) {
                        Text("Cancel", color = TextPrimary)
                    }
                }
            )
        }
    }
}
