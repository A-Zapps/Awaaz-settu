package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Awaaz Setu Color Palette - High Contrast, Accessible, Trustworthy
val BrandNavy = Color(0xFF1B365D)        // Deep Navy / Purple-Blue (#1B365D) for primary buttons & trust
val BrandNavyDark = Color(0xFF0F223D)
val BrandOrange = Color(0xFFE85D04)      // Vibrant Heritage Orange for accents & badges
val BrandOrangeLight = Color(0xFFFFF3EB)

val LightCanvas = Color(0xFFF7F5F9)      // Single clean light neutral background (#EFE4F0 / #F7F5F9)
val SurfaceCard = Color(0xFFFFFFFF)      // Pure white card surfaces for high contrast
val TextPrimary = Color(0xFF111827)      // Near-black text (~16:1 contrast)
val TextSecondary = Color(0xFF4B5563)    // Mid-gray for secondary captions
val BorderStroke = Color(0xFFE2DCE8)

val SuccessGreen = Color(0xFF15803D)     // Forest Green for verified / resolved
val SuccessBg = Color(0xFFF0FDF4)
val WarningAmber = Color(0xFFB45309)     // Amber for under review
val WarningBg = Color(0xFFFFFBEB)
val InfoBlue = Color(0xFF1D4ED8)
val InfoBg = Color(0xFFEFF6FF)
val ErrorRed = Color(0xFFB91C1C)
val ErrorBg = Color(0xFFFEF2F2)
