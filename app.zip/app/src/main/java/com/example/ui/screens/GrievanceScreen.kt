package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.GrievanceItem
import com.example.data.model.GrievanceStatus
import com.example.ui.components.AwaazTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GrievanceScreen(viewModel: AwaazViewModel) {
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val selectedScheme by viewModel.selectedSchemeForGrievance.collectAsStateWithLifecycle()
    val grievances by viewModel.allGrievances.collectAsStateWithLifecycle()
    val isListening by viewModel.speechHelper.isListening.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = File Grievance, 1 = Track Grievances
    var grievanceCategory by remember { mutableStateOf("Payment / Subsidy Delay") }
    var descriptionText by remember { mutableStateOf("") }
    var citizenName by remember { mutableStateOf(userName) }
    var citizenPhone by remember { mutableStateOf("9848022334") }
    var lastSubmittedTrackingId by remember { mutableStateOf<String?>(null) }
    var showConfirmationDialog by remember { mutableStateOf(false) }

    val categories = listOf(
        "Payment / Subsidy Delay",
        "Application Rejected without Reason",
        "Name Missing in Beneficiary List",
        "Bribery / Corruption Complaint",
        "CSC Center Misbehavior",
        "Other Grievance"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        AwaazTopBar(
            viewModel = viewModel,
            title = when (currentLang) {
                AppLanguage.HINDI -> "शिकायत निवारण (Grievance)"
                AppLanguage.TELUGU -> "ఫిర్యాదుల విభాగం"
                AppLanguage.ENGLISH -> "Grievance Redressal"
            },
            showBack = true,
            onBack = { viewModel.navigateTo(Screen.HOME) }
        )

        // 2 Tabs: File Grievance vs Track Grievances
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SurfaceCard,
            contentColor = BrandNavy,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = BrandOrange,
                    height = 3.dp
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "नई शिकायत"
                            AppLanguage.TELUGU -> "కొత్త ఫిర్యాదు"
                            AppLanguage.ENGLISH -> "File Grievance"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                    )
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "स्थिति जांचें (${grievances.size})"
                            AppLanguage.TELUGU -> "ట్రాకింగ్ (${grievances.size})"
                            AppLanguage.ENGLISH -> "Track (${grievances.size})"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                    )
                }
            )
        }

        if (selectedTab == 0) {
            // FILE GRIEVANCE FORM
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Success confirmation banner if just submitted
                if (lastSubmittedTrackingId != null) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = BrandNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = BrandOrange,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "Grievance Registered Successfully!",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Your Tracking Number: $lastSubmittedTrackingId",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isOnline) "Forwarded to District Welfare Redressal Nodal Cell." else "Saved in local queue. Will sync automatically once online.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }
                    }
                }

                // Scheme banner if filing for specific scheme
                if (selectedScheme != null) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BrandNavy.copy(alpha = 0.08f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ReportProblem,
                                    contentDescription = null,
                                    tint = BrandNavy,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Selected Scheme:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = selectedScheme?.getName(currentLang) ?: "",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = BrandNavy,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Step 1: Speak or Type Complaint
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "1. अपनी शिकायत बोलें या लिखें"
                                    AppLanguage.TELUGU -> "1. మీ సమస్యను మాట్లాడండి లేదా రాయండి"
                                    AppLanguage.ENGLISH -> "1. Speak or Type Your Grievance"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Static Microphone button
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isListening) BrandOrange else BrandNavy
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isListening) {
                                            viewModel.speechHelper.stopListening()
                                        } else {
                                            viewModel.ttsManager.stop()
                                            viewModel.speechHelper.startListening(currentLang) { text ->
                                                descriptionText = if (descriptionText.isBlank()) text else "$descriptionText $text"
                                            }
                                        }
                                    }
                                    .testTag("grievance_voice_record_button")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = if (isListening) Icons.Default.Hearing else Icons.Default.Mic,
                                        contentDescription = "Mic",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = if (isListening) "Listening... Speak now" else "Speak your grievance (अपनी शिकायत बोलें)",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Text area for complaint
                            val solidBlack = Color(0xFF0F172A)
                            val gTextFieldColors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = solidBlack,
                                unfocusedTextColor = solidBlack,
                                focusedBorderColor = BrandNavy,
                                unfocusedBorderColor = Color(0xFF94A3B8),
                                focusedLabelColor = BrandNavy,
                                unfocusedLabelColor = Color(0xFF475569),
                                focusedPlaceholderColor = Color(0xFF94A3B8),
                                unfocusedPlaceholderColor = Color(0xFF94A3B8),
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White
                            )

                            OutlinedTextField(
                                value = descriptionText,
                                onValueChange = { descriptionText = it },
                                placeholder = {
                                    Text("Describe the issue, e.g. Installment delayed by 4 months, Mandal officer refused document...")
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .testTag("grievance_description_input"),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = solidBlack,
                                    fontWeight = FontWeight.Medium
                                ),
                                colors = gTextFieldColors
                            )
                        }
                    }
                }

                // Category Selection
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "2. Select Grievance Category",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            categories.forEach { category ->
                                val isSelected = grievanceCategory == category
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) BrandNavy else LightCanvas,
                                    border = BorderStroke(1.dp, if (isSelected) BrandNavy else Color(0xFFD1D5DB)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable { grievanceCategory = category }
                                ) {
                                    Text(
                                        text = category,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = if (isSelected) Color.White else TextPrimary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Citizen Contact Info
                item {
                    val solidBlack = Color(0xFF0F172A)
                    val gTextFieldColors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = solidBlack,
                        unfocusedTextColor = solidBlack,
                        focusedBorderColor = BrandNavy,
                        unfocusedBorderColor = Color(0xFF94A3B8),
                        focusedLabelColor = BrandNavy,
                        unfocusedLabelColor = Color(0xFF475569),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "3. Citizen Contact Details",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = citizenName,
                                onValueChange = { citizenName = it },
                                label = { Text("Citizen Full Name") },
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = solidBlack,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                colors = gTextFieldColors,
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = citizenPhone,
                                onValueChange = { citizenPhone = it },
                                label = { Text("Mobile Number for SMS & Call Updates") },
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = solidBlack,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                colors = gTextFieldColors,
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                }


                // STEP 2: CONFIRM & SUBMIT BUTTON (Section 7 UI/UX Design Doc)
                item {
                    Button(
                        onClick = {
                            if (descriptionText.isBlank()) {
                                descriptionText = "Installment for recent scheme application delayed at Mandal Revenue office."
                            }
                            viewModel.submitGrievance(
                                schemeId = selectedScheme?.id,
                                schemeName = selectedScheme?.getName(currentLang) ?: "General Public Welfare",
                                category = grievanceCategory,
                                description = descriptionText,
                                isVoice = true,
                                citizenName = citizenName,
                                phone = citizenPhone,
                                state = profile.state
                            ) { trackingId ->
                                lastSubmittedTrackingId = trackingId
                                descriptionText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrandOrange,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .testTag("submit_grievance_button")
                    ) {
                        Text(
                            text = when (currentLang) {
                                AppLanguage.HINDI -> "पुष्टि करें और शिकायत जमा करें"
                                AppLanguage.TELUGU -> "నిర్ధారించి ఫిర్యాదు సమర్పించండి"
                                AppLanguage.ENGLISH -> "Confirm & Submit Grievance"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        } else {
            // TRACK GRIEVANCES LIST & STATUS TIMELINE
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (grievances.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "No grievances filed yet",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                } else {
                    items(grievances, key = { it.id }) { grievance ->
                        val statusColor = when (grievance.status) {
                            GrievanceStatus.RESOLVED -> SuccessGreen
                            GrievanceStatus.IN_PROGRESS -> BrandOrange
                            GrievanceStatus.UNDER_REVIEW -> WarningAmber
                            GrievanceStatus.SUBMITTED -> BrandNavy
                        }

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("grievance_item_${grievance.trackingNumber}")
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = grievance.trackingNumber,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = BrandNavy,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = statusColor.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = grievance.status.getTitle(currentLang),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = grievance.schemeName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = "Category: ${grievance.category}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = LightCanvas,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "\"${grievance.description}\"",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = TextPrimary,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }

                                if (grievance.officerRemarks.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Officer Remarks: ${grievance.officerRemarks}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = BrandNavy,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = Color(0xFFF3F4F6))
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(grievance.createdAt))
                                    Text(
                                        text = dateStr,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )

                                    // Voice read out for tracking
                                    IconButton(
                                        onClick = {
                                            val ttsText = "शिकायत नंबर ${grievance.trackingNumber}। स्थिति: ${grievance.status.getTitle(currentLang)}। " +
                                                    (if (grievance.officerRemarks.isNotBlank()) "अधिकारी की टिप्पणी: ${grievance.officerRemarks}" else "")
                                            viewModel.ttsManager.speak(ttsText, currentLang)
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                            contentDescription = "Read grievance status",
                                            tint = BrandNavy
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
