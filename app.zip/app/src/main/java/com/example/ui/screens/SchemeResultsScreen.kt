package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.AiSchemeAdvisor
import com.example.data.model.AppLanguage
import com.example.data.model.Scheme
import com.example.ui.components.AwaazTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen

@Composable
fun SchemeResultsScreen(viewModel: AwaazViewModel) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val schemes by viewModel.matchedSchemes.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsStateWithLifecycle()
    val currentUtteranceId by viewModel.ttsManager.currentPlayingId.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val schemeStepsMap by viewModel.schemeStepsMap.collectAsStateWithLifecycle()
    val loadingStepsSchemeId by viewModel.loadingStepsSchemeId.collectAsStateWithLifecycle()

    var selectedCategory by remember { mutableStateOf("ALL") }

    val categories = listOf("ALL", "Agriculture", "Healthcare", "Housing", "Employment", "Social Welfare")

    val filteredSchemes = if (selectedCategory == "ALL") {
        schemes
    } else {
        schemes.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        AwaazTopBar(
            viewModel = viewModel,
            title = when (currentLang) {
                AppLanguage.HINDI -> "पात्र सरकारी योजनाएं"
                AppLanguage.TELUGU -> "అర్హతగల పథకాలు"
                AppLanguage.ENGLISH -> "Eligible Schemes"
            },
            showBack = true,
            onBack = { viewModel.navigateTo(Screen.HOME) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Results summary header
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, Color(0xFFE2DCE8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "${schemes.size} योजनाएं आपके लिए उपयुक्त"
                                    AppLanguage.TELUGU -> "${schemes.size} పథకాలు సరిపోలాయి"
                                    AppLanguage.ENGLISH -> "${schemes.size} Schemes Matched"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Age: ${profile.age} yrs • ${profile.gender} • ${profile.state}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }

                        IconButton(
                            onClick = { viewModel.startVoiceIntake() },
                            modifier = Modifier
                                .size(44.dp)
                                .background(BrandNavy.copy(alpha = 0.08f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit answers",
                                tint = BrandNavy,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            // Category Filter Row
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { category ->
                        val isSelected = selectedCategory == category
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = category },
                            label = {
                                Text(
                                    text = if (category == "ALL") "All Categories" else category,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandNavy,
                                selectedLabelColor = Color.White,
                                containerColor = SurfaceCard,
                                labelColor = TextPrimary
                            )
                        )
                    }
                }
            }

            // Scheme Cards
            items(filteredSchemes, key = { it.id }) { scheme ->
                val isThisSpeaking = isSpeaking && currentUtteranceId == scheme.id
                val isStepsSpeaking = isSpeaking && currentUtteranceId == "steps_${scheme.id}"
                val stepsText = schemeStepsMap[scheme.id] ?: AiSchemeAdvisor.getPredefinedSteps(scheme, currentLang, profile)
                val isStepsLoading = loadingStepsSchemeId == scheme.id
                var showSteps by remember { mutableStateOf(false) }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(
                        width = if (isThisSpeaking || isStepsSpeaking) 2.dp else 1.dp,
                        color = if (isThisSpeaking || isStepsSpeaking) BrandOrange else Color(0xFFE2DCE8)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("scheme_card_${scheme.id}")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        // Central vs State Badge & Category
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (scheme.isCentral) BrandNavy.copy(alpha = 0.12f) else BrandOrange.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (scheme.isCentral) Icons.Default.AccountBalance else Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = if (scheme.isCentral) BrandNavy else BrandOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (scheme.isCentral) "Central Scheme" else "${scheme.stateName ?: "State"} Govt",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (scheme.isCentral) BrandNavy else BrandOrange
                                    )
                                }
                            }

                            Text(
                                text = scheme.category,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Scheme Name
                        Text(
                            text = scheme.getName(currentLang),
                            style = MaterialTheme.typography.titleLarge,
                            color = BrandNavy,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Benefit (Short Sentence)
                        Column {
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "लाभ (Benefit):"
                                    AppLanguage.TELUGU -> "ప్రయోజనం (Benefit):"
                                    AppLanguage.ENGLISH -> "Benefit:"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = BrandOrange,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = scheme.getBenefit(currentLang),
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Normal
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Eligibility (Short Sentence)
                        Column {
                            Text(
                                text = when (currentLang) {
                                    AppLanguage.HINDI -> "पात्रता (Eligibility):"
                                    AppLanguage.TELUGU -> "అర్హత (Eligibility):"
                                    AppLanguage.ENGLISH -> "Eligibility:"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = BrandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = scheme.getEligibility(currentLang),
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Normal
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Color(0xFFF3F4F6))
                        Spacer(modifier = Modifier.height(14.dp))

                        // ACTION ROW 1: "Read this to me" (On-device TTS) & "Apply" (Official Portal)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // "Read this to me" Button
                            Button(
                                onClick = {
                                    if (isThisSpeaking) {
                                        viewModel.stopTts()
                                    } else {
                                        viewModel.readSchemeCard(scheme)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isThisSpeaking) BrandOrange else BrandNavy.copy(alpha = 0.1f),
                                    contentColor = if (isThisSpeaking) Color.White else BrandNavy
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("tts_read_scheme_${scheme.id}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = if (isThisSpeaking) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = "Read out",
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isThisSpeaking) "Stop" else when (currentLang) {
                                            AppLanguage.HINDI -> "पढ़कर सुनाएं"
                                            AppLanguage.TELUGU -> "వినిపించు"
                                            AppLanguage.ENGLISH -> "Read to Me"
                                        },
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }

                            // "Apply" Official Link Button
                            Button(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(scheme.applyUrl))
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandNavy,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("apply_scheme_${scheme.id}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = when (currentLang) {
                                            AppLanguage.HINDI -> "आवेदन करें"
                                            AppLanguage.TELUGU -> "దరఖాస్తు"
                                            AppLanguage.ENGLISH -> "Apply"
                                        },
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.OpenInNew,
                                        contentDescription = "Open portal",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // REPLACED: AI Generated Application Steps Section
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                            border = BorderStroke(1.2.dp, if (showSteps) BrandNavy else Color(0xFFE2E8F0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (!showSteps && !schemeStepsMap.containsKey(scheme.id)) {
                                                viewModel.loadOrGenerateStepsForScheme(scheme)
                                            }
                                            showSteps = !showSteps
                                        },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = CircleShape,
                                            color = BrandNavy.copy(alpha = 0.1f),
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Default.AutoAwesome,
                                                    contentDescription = null,
                                                    tint = BrandOrange,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = when (currentLang) {
                                                    AppLanguage.HINDI -> "आवेदन करने के AI चरण"
                                                    AppLanguage.TELUGU -> "దరఖాస్తు దశలు (AI)"
                                                    AppLanguage.ENGLISH -> "AI Steps to Apply"
                                                },
                                                style = MaterialTheme.typography.titleSmall,
                                                color = BrandNavy,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (showSteps) "Tap to collapse" else "Generate step-by-step guidance",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = TextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (isStepsLoading) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(18.dp),
                                                strokeWidth = 2.dp,
                                                color = BrandNavy
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                        }
                                        Icon(
                                            imageVector = if (showSteps) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = "Toggle steps",
                                            tint = BrandNavy,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }

                                AnimatedVisibility(
                                    visible = showSteps,
                                    enter = fadeIn() + expandVertically(),
                                    exit = fadeOut() + shrinkVertically()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 10.dp)
                                    ) {
                                        HorizontalDivider(color = Color(0xFFE2E8F0))
                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Step Content Box formatted as requested
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color.White,
                                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                // Raw Step Rendering exactly formatted: ste1: ... ste2: ... step3: end
                                                val lines = stepsText.split("\n")
                                                lines.forEach { line ->
                                                    val trimmed = line.trim()
                                                    if (trimmed.startsWith("step", ignoreCase = true) || trimmed.startsWith("ste", ignoreCase = true)) {
                                                        Text(
                                                            text = trimmed,
                                                            style = MaterialTheme.typography.labelLarge,
                                                            color = BrandNavy,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                                                        )
                                                    } else if (trimmed.equals("end", ignoreCase = true)) {
                                                        Text(
                                                            text = "end",
                                                            style = MaterialTheme.typography.labelMedium,
                                                            color = SuccessGreen,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(vertical = 2.dp)
                                                        )
                                                    } else if (trimmed.isNotBlank()) {
                                                        Text(
                                                            text = trimmed,
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            color = Color(0xFF1E293B),
                                                            lineHeight = 20.sp,
                                                            modifier = Modifier.padding(bottom = 6.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Action controls for steps: TTS Read Aloud + Regenerate
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Button(
                                                onClick = {
                                                    if (isStepsSpeaking) {
                                                        viewModel.stopTts()
                                                    } else {
                                                        viewModel.readStepsToApply(scheme, stepsText)
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (isStepsSpeaking) BrandOrange else BrandNavy,
                                                    contentColor = Color.White
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(38.dp)
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = if (isStepsSpeaking) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = if (isStepsSpeaking) "Stop Voice" else "Listen to Steps",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    viewModel.loadOrGenerateStepsForScheme(scheme, forceRefresh = true)
                                                },
                                                border = BorderStroke(1.dp, BrandNavy),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(38.dp)
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = Icons.Default.Refresh,
                                                        contentDescription = null,
                                                        tint = BrandNavy,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "AI Regenerate",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        color = BrandNavy,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
