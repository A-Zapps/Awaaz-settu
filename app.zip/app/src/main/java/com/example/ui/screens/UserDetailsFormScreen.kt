package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.LightCanvas
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen

private val StatesList = listOf(
    "Telangana",
    "Andhra Pradesh",
    "Uttar Pradesh",
    "Maharashtra",
    "Karnataka",
    "Tamil Nadu",
    "Bihar",
    "Madhya Pradesh",
    "Rajasthan",
    "Gujarat",
    "West Bengal",
    "Odisha",
    "Kerala",
    "Punjab",
    "Haryana",
    "Assam",
    "Jharkhand",
    "Chhattisgarh"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserDetailsFormScreen(viewModel: AwaazViewModel) {
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val googleName by viewModel.userName.collectAsStateWithLifecycle()
    val googleEmail by viewModel.userEmail.collectAsStateWithLifecycle()
    val initialProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    var isForSelf by remember { mutableStateOf(true) }
    var beneficiaryName by remember(googleName) { mutableStateOf(googleName) }
    var phoneNumber by remember { mutableStateOf("9848022338") }
    var ageText by remember { mutableStateOf(if (initialProfile.age > 0) initialProfile.age.toString() else "42") }
    var selectedGender by remember { mutableStateOf(initialProfile.gender.ifBlank { "MALE" }) }
    var selectedState by remember { mutableStateOf(initialProfile.state.ifBlank { "Telangana" }) }
    var districtText by remember { mutableStateOf("Sangareddy") }
    var incomeNumberText by remember { mutableStateOf("150000") }
    var selectedIncomeBracket by remember { mutableDoubleStateOf(1.5) }
    var consentAgreed by remember { mutableStateOf(true) }
    var isStateExpanded by remember { mutableStateOf(false) }

    var nameError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var ageError by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightCanvas)
    ) {
        // Top Navigation & Voice Header
        Surface(
            color = Color.White,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(Screen.AUTH_LANGUAGE) },
                    modifier = Modifier.testTag("details_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Sign In",
                        tint = BrandNavy
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "नागरिक विवरण प्रपत्र"
                            AppLanguage.TELUGU -> "పౌర వివరాల నమోదు"
                            AppLanguage.ENGLISH -> "Citizen Profile Details"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = BrandNavy
                    )
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "योजनाओं की पात्रता हेतु विवरण भरें"
                            AppLanguage.TELUGU -> "పథకాల అర్హత కోసం వివరాలు నింపండి"
                            AppLanguage.ENGLISH -> "Step 2 of 2 • Welfare Scheme Matching"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                // TTS Read Aloud Button
                IconButton(
                    onClick = {
                        val prompt = when (currentLang) {
                            AppLanguage.HINDI -> "कृपया अपने विवरण भरें जैसे नाम, आयु, लिंग और राज्य, ताकि हम आपको सही सरकारी योजनाओं से जोड़ सकें।"
                            AppLanguage.TELUGU -> "దయచేసి మీ పేరు, వయస్సు, లింగం మరియు రాష్ట్రం వివరాలను నమోదు చేయండి."
                            AppLanguage.ENGLISH -> "Please complete your details including age, gender, and state to find eligible government welfare schemes."
                        }
                        viewModel.ttsManager.speak(prompt, currentLang)
                    },
                    modifier = Modifier.testTag("details_tts_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Read Form Instructions",
                        tint = BrandOrange
                    )
                }
            }
        }

        // Form Field Colors with high-contrast solid black text
        val solidBlack = Color(0xFF0F172A)
        val formFieldColors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = solidBlack,
            unfocusedTextColor = solidBlack,
            disabledTextColor = solidBlack,
            focusedBorderColor = BrandNavy,
            unfocusedBorderColor = Color(0xFF94A3B8),
            focusedLabelColor = BrandNavy,
            unfocusedLabelColor = Color(0xFF475569),
            focusedPlaceholderColor = Color(0xFF94A3B8),
            unfocusedPlaceholderColor = Color(0xFF94A3B8),
            focusedPrefixColor = solidBlack,
            unfocusedPrefixColor = solidBlack,
            focusedLeadingIconColor = BrandNavy,
            unfocusedLeadingIconColor = BrandNavy,
            focusedTrailingIconColor = BrandNavy,
            unfocusedTrailingIconColor = BrandNavy,
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
        )

        // Form Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            // Google Account Connected Card
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = BrandNavy.copy(alpha = 0.05f),
                border = BorderStroke(1.dp, BrandNavy.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = BrandNavy,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = googleName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BrandNavy
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified Google Account",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = googleEmail,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 1: Beneficiary Name
            Text(
                text = when (currentLang) {
                    AppLanguage.HINDI -> "1. लाभार्थी का पूरा नाम"
                    AppLanguage.TELUGU -> "1. లబ్ధిదారుని పూర్తి పేరు"
                    AppLanguage.ENGLISH -> "1. Full Beneficiary Name"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrandNavy
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = beneficiaryName,
                onValueChange = {
                    beneficiaryName = it
                    nameError = if (it.isBlank()) "Name cannot be empty" else null
                },
                label = { Text("Full Name (as on Aadhaar/Govt ID)") },
                isError = nameError != null,
                supportingText = nameError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = solidBlack,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_beneficiary_name"),
                colors = formFieldColors
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: Mobile Number
            Text(
                text = when (currentLang) {
                    AppLanguage.HINDI -> "2. मोबाइल नंबर (एसएमएस अलर्ट के लिए)"
                    AppLanguage.TELUGU -> "2. మొబైల్ నంబర్ (SMS అలర్ట్‌ల కోసం)"
                    AppLanguage.ENGLISH -> "2. Mobile Number (For Tracking & SMS)"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrandNavy
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = phoneNumber,
                onValueChange = {
                    val filtered = it.filter { ch -> ch.isDigit() }.take(10)
                    phoneNumber = filtered
                    phoneError = if (filtered.length < 10) "Enter 10-digit mobile number" else null
                },
                prefix = { Text("+91  ", fontWeight = FontWeight.Bold, color = solidBlack) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = BrandNavy
                    )
                },
                label = { Text("10-Digit Mobile Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                isError = phoneError != null,
                supportingText = phoneError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = solidBlack,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_phone_number"),
                colors = formFieldColors
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 3: Age
            Text(
                text = when (currentLang) {
                    AppLanguage.HINDI -> "3. आयु (वर्ष)"
                    AppLanguage.TELUGU -> "3. వయస్సు (సంవత్సరాలు)"
                    AppLanguage.ENGLISH -> "3. Age (Years)"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrandNavy
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = ageText,
                onValueChange = {
                    val filtered = it.filter { ch -> ch.isDigit() }.take(3)
                    ageText = filtered
                    val num = filtered.toIntOrNull()
                    ageError = if (num == null || num < 0 || num > 115) "Please enter a valid age (0-115)" else null
                },
                label = { Text("Age in Years (e.g. 8, 16, 35)") },
                placeholder = { Text("Enter beneficiary age (all age groups welcome)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = ageError != null,
                supportingText = ageError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = solidBlack,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_age"),
                colors = formFieldColors
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 4: Gender Selection
            Text(
                text = when (currentLang) {
                    AppLanguage.HINDI -> "4. लिंग"
                    AppLanguage.TELUGU -> "4. లింగం"
                    AppLanguage.ENGLISH -> "4. Gender"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrandNavy
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf(
                    "MALE" to "Male",
                    "FEMALE" to "Female",
                    "OTHER" to "Other"
                ).forEach { (code, label) ->
                    val isSel = selectedGender.equals(code, ignoreCase = true)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSel) BrandOrange else Color.White,
                        border = BorderStroke(
                            width = if (isSel) 2.dp else 1.5.dp,
                            color = if (isSel) BrandOrange else Color(0xFF94A3B8)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clickable { selectedGender = code }
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) Color.White else solidBlack,
                                fontSize = 14.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 5: State & District
            Text(
                text = when (currentLang) {
                    AppLanguage.HINDI -> "5. राज्य एवं जिला"
                    AppLanguage.TELUGU -> "5. రాష్ట్రం మరియు జిల్లా"
                    AppLanguage.ENGLISH -> "5. State & District"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrandNavy
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // State Dropdown
                ExposedDropdownMenuBox(
                    expanded = isStateExpanded,
                    onExpandedChange = { isStateExpanded = !isStateExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = selectedState,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("State") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStateExpanded)
                        },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = solidBlack,
                            fontWeight = FontWeight.SemiBold
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("dropdown_state"),
                        colors = formFieldColors
                    )

                    ExposedDropdownMenu(
                        expanded = isStateExpanded,
                        onDismissRequest = { isStateExpanded = false }
                    ) {
                        StatesList.forEach { stateName ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        stateName,
                                        color = solidBlack,
                                        fontWeight = FontWeight.Medium
                                    )
                                },
                                onClick = {
                                    selectedState = stateName
                                    isStateExpanded = false
                                }
                            )
                        }
                    }
                }

                // District
                OutlinedTextField(
                    value = districtText,
                    onValueChange = { districtText = it },
                    label = { Text("District") },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = solidBlack,
                        fontWeight = FontWeight.SemiBold
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_district"),
                    colors = formFieldColors
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 6: Annual Household Income
            Text(
                text = when (currentLang) {
                    AppLanguage.HINDI -> "6. वार्षिक पारिवारिक आय"
                    AppLanguage.TELUGU -> "6. వార్షిక కుటుంబ ఆదాయం"
                    AppLanguage.ENGLISH -> "6. Annual Household Income"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrandNavy
            )
            Text(
                text = "Enter exact numbers in rupees below or choose a quick bracket",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Box for Numbers Only
            OutlinedTextField(
                value = incomeNumberText,
                onValueChange = { input ->
                    val digits = input.filter { ch -> ch.isDigit() }.take(9)
                    incomeNumberText = digits
                    val num = digits.toDoubleOrNull() ?: 0.0
                    selectedIncomeBracket = (num / 100000.0).coerceAtLeast(0.0)
                },
                label = { Text("Annual Household Income (₹ Numbers Only)") },
                placeholder = { Text("e.g. 150000") },
                prefix = {
                    Text(
                        text = "₹ ",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = solidBlack,
                            fontWeight = FontWeight.Bold
                        )
                    )
                },
                supportingText = {
                    val num = incomeNumberText.toDoubleOrNull() ?: 0.0
                    val lakhs = num / 100000.0
                    Text(
                        text = "Amount: ₹${String.format(java.util.Locale.US, "%,.0f", num)} (≈ ${String.format(java.util.Locale.US, "%.2f", lakhs)} Lakhs/yr)",
                        color = BrandNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = solidBlack,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_annual_income_numeric"),
                colors = formFieldColors
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Preset Brackets that sync with number box
            Text(
                text = "Quick Presets:",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Pair("80000", "< ₹1.0 Lakh"),
                    Pair("150000", "₹1.0L - 2.5L"),
                    Pair("350000", "₹2.5L - 5.0L"),
                    Pair("600000", "> ₹5.0 Lakh")
                ).forEach { (presetVal, label) ->
                    val isSel = incomeNumberText == presetVal
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSel) BrandNavy else Color.White,
                        border = BorderStroke(
                            width = if (isSel) 2.dp else 1.5.dp,
                            color = if (isSel) BrandNavy else Color(0xFF94A3B8)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clickable {
                                incomeNumberText = presetVal
                                selectedIncomeBracket = (presetVal.toDoubleOrNull() ?: 0.0) / 100000.0
                            }
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 4.dp)
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) Color.White else solidBlack,
                                fontSize = 11.5.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))


            // DPDP Act 2023 Consent Guarantee
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF0FDF4),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = consentAgreed,
                        onCheckedChange = { consentAgreed = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = BrandNavy,
                            checkmarkColor = Color.White
                        ),
                        modifier = Modifier.testTag("checkbox_consent")
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "मैं भारत डीपी blockDP अधिनियम 2023 के तहत पात्रता मिलान हेतु यह डेटा सुरक्षित रूप से सहेजने की सहमति देता हूँ।"
                            AppLanguage.TELUGU -> "భారత DPDP చట్టం 2023 ప్రకారం సంక్షేమ పథకాల అర్హత కోసం నా డేటాను సురక్షితంగా నిల్వ చేయడానికి అంగీకరిస్తున్నాను."
                            AppLanguage.ENGLISH -> "I consent to store my profile locally for scheme matching under India DPDP Act 2023. Data is private & encrypted."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.5.sp,
                        color = Color(0xFF166534)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Proceed to Dashboard / Welcome Page Button
            Button(
                onClick = {
                    if (beneficiaryName.isBlank()) {
                        nameError = "Please enter beneficiary name"
                        return@Button
                    }
                    val ageVal = ageText.toIntOrNull() ?: 42
                    viewModel.submitRegistrationForm(
                        isForSelf = isForSelf,
                        beneficiaryName = beneficiaryName.trim(),
                        phone = phoneNumber.trim(),
                        age = ageVal,
                        gender = selectedGender,
                        state = selectedState,
                        incomeRangeLakhs = selectedIncomeBracket
                    )
                },
                enabled = consentAgreed && beneficiaryName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandOrange,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("submit_registration_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = when (currentLang) {
                            AppLanguage.HINDI -> "विवरण सहेजें एवं मुख्य पृष्ठ पर जाएं"
                            AppLanguage.TELUGU -> "వివరాలు సేవ్ చేసి హోమ్‌పేజీకి వెళ్లండి"
                            AppLanguage.ENGLISH -> "Save Details & Proceed to Welcome Page"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
