package com.example.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandOrange
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen

@Composable
fun AwaazBottomBar(viewModel: AwaazViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()

    val navItems = listOf(
        Triple(
            Screen.HOME,
            Icons.Default.Home,
            when (currentLang) {
                AppLanguage.HINDI -> "होम"
                AppLanguage.TELUGU -> "హోమ్"
                AppLanguage.ENGLISH -> "Home"
            }
        ),
        Triple(
            Screen.SCHEME_RESULTS,
            Icons.Default.Assignment,
            when (currentLang) {
                AppLanguage.HINDI -> "योजनाएं"
                AppLanguage.TELUGU -> "పథకాలు"
                AppLanguage.ENGLISH -> "Schemes"
            }
        ),
        Triple(
            Screen.GRIEVANCE_FORM,
            Icons.Default.ReportProblem,
            when (currentLang) {
                AppLanguage.HINDI -> "शिकायत"
                AppLanguage.TELUGU -> "ఫిర్యాదు"
                AppLanguage.ENGLISH -> "Grievance"
            }
        ),
        Triple(
            Screen.MY_DOCUMENTS,
            Icons.Default.FolderShared,
            when (currentLang) {
                AppLanguage.HINDI -> "दस्तावेज़"
                AppLanguage.TELUGU -> "పత్రాలు"
                AppLanguage.ENGLISH -> "Documents"
            }
        ),
        Triple(
            Screen.PROFILE,
            Icons.Default.Person,
            when (currentLang) {
                AppLanguage.HINDI -> "प्रोफ़ाइल"
                AppLanguage.TELUGU -> "ప్రొఫైల్"
                AppLanguage.ENGLISH -> "Profile"
            }
        )
    )

    NavigationBar(
        containerColor = Color.White,
        contentColor = BrandNavy,
        tonalElevation = 8.dp
    ) {
        navItems.forEach { (screen, icon, label) ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    if (currentScreen != screen) {
                        viewModel.navigateTo(screen)
                    }
                },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandOrange,
                    selectedTextColor = BrandNavy,
                    unselectedIconColor = Color(0xFF6B7280),
                    unselectedTextColor = Color(0xFF6B7280),
                    indicatorColor = BrandOrange.copy(alpha = 0.14f)
                ),
                modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
            )
        }
    }
}
