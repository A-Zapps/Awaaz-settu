package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class AudioTtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentPlayingId = MutableStateFlow<String?>(null)
    val currentPlayingId: StateFlow<String?> = _currentPlayingId.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("AudioTtsManager", "TTS initialization error", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                    _currentPlayingId.value = utteranceId
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    _currentPlayingId.value = null
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    _currentPlayingId.value = null
                }
            })
            tts?.setSpeechRate(0.9f) // slightly slower for better clarity for low-literacy users
            tts?.setPitch(1.0f)
        } else {
            isInitialized = false
            Log.w("AudioTtsManager", "TTS init failed with status: $status")
        }
    }

    fun speak(text: String, language: AppLanguage, utteranceId: String = "awaaz_tts_${System.currentTimeMillis()}") {
        if (tts == null) return
        stop()

        val locale = when (language) {
            AppLanguage.HINDI -> Locale("hi", "IN")
            AppLanguage.TELUGU -> Locale("te", "IN")
            AppLanguage.ENGLISH -> Locale("en", "IN")
        }

        try {
            val result = tts?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to default or English
                tts?.setLanguage(Locale.ENGLISH)
            }
            _isSpeaking.value = true
            _currentPlayingId.value = utteranceId
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.e("AudioTtsManager", "Error speaking text", e)
            _isSpeaking.value = false
            _currentPlayingId.value = null
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.e("AudioTtsManager", "Error stopping TTS", e)
        }
        _isSpeaking.value = false
        _currentPlayingId.value = null
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            Log.e("AudioTtsManager", "Error shutting down TTS", e)
        }
    }
}
