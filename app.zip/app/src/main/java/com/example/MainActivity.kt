package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AwaazBottomBar
import com.example.ui.components.NotificationToast
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AuthLanguageScreen
import com.example.ui.screens.DocumentsScreen
import com.example.ui.screens.GrievanceScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SchemeResultsScreen
import com.example.ui.screens.UserDetailsFormScreen
import com.example.ui.screens.VoiceIntakeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AwaazViewModel
import com.example.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: AwaazViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                AwaazSetuApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AwaazSetuApp(viewModel: AwaazViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val notificationBanner by viewModel.notificationBanner.collectAsStateWithLifecycle()

    // Runtime Permission for Voice Recording
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // Handled gracefully in SpeechRecognizerHelper
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Back button handling
    BackHandler(enabled = currentScreen != Screen.AUTH_LANGUAGE && currentScreen != Screen.HOME) {
        when (currentScreen) {
            Screen.USER_DETAILS_FORM -> viewModel.navigateTo(Screen.AUTH_LANGUAGE)
            Screen.VOICE_INTAKE -> viewModel.previousIntakeStep()
            Screen.SCHEME_RESULTS,
            Screen.GRIEVANCE_FORM,
            Screen.MY_DOCUMENTS,
            Screen.PROFILE -> viewModel.navigateTo(Screen.HOME)
            Screen.ADMIN_DASHBOARD -> viewModel.navigateTo(Screen.AUTH_LANGUAGE)
            else -> {}
        }
    }

    val showBottomBar = currentScreen in listOf(
        Screen.HOME,
        Screen.SCHEME_RESULTS,
        Screen.GRIEVANCE_FORM,
        Screen.MY_DOCUMENTS,
        Screen.PROFILE
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                AwaazBottomBar(viewModel = viewModel)
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Screen Routing
            when (currentScreen) {
                Screen.AUTH_LANGUAGE -> AuthLanguageScreen(viewModel = viewModel)
                Screen.USER_DETAILS_FORM -> UserDetailsFormScreen(viewModel = viewModel)
                Screen.HOME -> HomeScreen(viewModel = viewModel)
                Screen.VOICE_INTAKE -> VoiceIntakeScreen(viewModel = viewModel)
                Screen.SCHEME_RESULTS -> SchemeResultsScreen(viewModel = viewModel)
                Screen.GRIEVANCE_FORM -> GrievanceScreen(viewModel = viewModel)
                Screen.MY_DOCUMENTS -> DocumentsScreen(viewModel = viewModel)
                Screen.PROFILE -> ProfileScreen(viewModel = viewModel)
                Screen.ADMIN_DASHBOARD -> AdminDashboardScreen(viewModel = viewModel)
            }

            // High-priority notification banner toast
            Box(
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                NotificationToast(
                    message = notificationBanner,
                    onDismiss = { viewModel.dismissBanner() }
                )
            }
        }
    }
}
