package com.example.data.model

enum class GrievanceStatus(val titleEn: String, val titleHi: String, val titleTe: String) {
    SUBMITTED("Submitted", "जमा किया गया", "సమర్పించబడింది"),
    UNDER_REVIEW("Under Review", "समीक्षाधीन", "పరిశీలనలో ఉంది"),
    IN_PROGRESS("In Progress", "प्रगति पर है", "పురోగతిలో ఉంది"),
    RESOLVED("Resolved", "समाधान हो गया", "పరిష్కరించబడింది");

    fun getTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.HINDI -> titleHi
        AppLanguage.TELUGU -> titleTe
        AppLanguage.ENGLISH -> titleEn
    }
}

data class GrievanceItem(
    val id: Long = 0,
    val trackingNumber: String,
    val schemeId: String?,
    val schemeName: String,
    val category: String,
    val description: String,
    val isVoiceRecorded: Boolean,
    val citizenName: String,
    val citizenPhone: String,
    val state: String,
    val status: GrievanceStatus,
    val officerRemarks: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = true // False when queued offline
)

enum class DocumentCategory(val titleEn: String, val titleHi: String, val titleTe: String) {
    IDENTITY_PROOF("Identity Proof", "पहचान प्रमाण", "గుర్తింపు రుజువు"),
    INCOME_CERTIFICATE("Income Certificate", "आय प्रमाण पत्र", "ఆదాయ ధృవీకరణ పత్రం"),
    LAND_RECORD("Land / Farm Record", "भूमि / खेत का रिकॉर्ड", "భూమి / వ్యవసాయ రికార్డు"),
    CASTE_CERTIFICATE("Caste Certificate", "जाति प्रमाण पत्र", "కుల ధృవీకరణ పత్రం"),
    APPLICATION_SUMMARY("Filled Application", "भरा हुआ आवेदन पत्र", "పూరించిన దరఖాస్తు");

    fun getTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.HINDI -> titleHi
        AppLanguage.TELUGU -> titleTe
        AppLanguage.ENGLISH -> titleEn
    }
}

data class DocumentItem(
    val id: Long = 0,
    val title: String,
    val category: DocumentCategory,
    val fileName: String,
    val uploadDate: String,
    val fileSizeKb: Int,
    val retentionDaysRemaining: Int = 365,
    val isEncrypted: Boolean = true
)

data class UserIntakeProfile(
    val id: Long = 1,
    val isForSelf: Boolean = true,
    val beneficiaryName: String = "",
    val age: Int = 0,
    val gender: String = "MALE", // "MALE", "FEMALE", "OTHER"
    val state: String = "Telangana",
    val occupation: String = "",
    val incomeRangeLakhs: Double = 1.0, // Annual family income in Lakhs
    val languageCode: String = "en",
    val lastUpdated: Long = System.currentTimeMillis()
)
