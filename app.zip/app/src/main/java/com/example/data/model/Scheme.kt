package com.example.data.model

data class Scheme(
    val id: String,
    val nameEn: String,
    val nameHi: String,
    val nameTe: String,
    val isCentral: Boolean,
    val stateName: String? = null, // null for Central Schemes, e.g. "Telangana"
    val category: String, // Agriculture, Healthcare, Housing, Social Welfare, Employment
    val benefitEn: String,
    val benefitHi: String,
    val benefitTe: String,
    val eligibilityEn: String,
    val eligibilityHi: String,
    val eligibilityTe: String,
    val applyUrl: String,
    val minAge: Int = 0,
    val maxAge: Int = 120,
    val targetGender: String = "ALL", // "ALL", "MALE", "FEMALE"
    val allowedOccupations: List<String> = emptyList(), // empty means all
    val maxIncomeLakhs: Double = 10.0 // maximum annual family income in Lakhs
) {
    fun getName(lang: AppLanguage): String = when (lang) {
        AppLanguage.HINDI -> nameHi
        AppLanguage.TELUGU -> nameTe
        AppLanguage.ENGLISH -> nameEn
    }

    fun getBenefit(lang: AppLanguage): String = when (lang) {
        AppLanguage.HINDI -> benefitHi
        AppLanguage.TELUGU -> benefitTe
        AppLanguage.ENGLISH -> benefitEn
    }

    fun getEligibility(lang: AppLanguage): String = when (lang) {
        AppLanguage.HINDI -> eligibilityHi
        AppLanguage.TELUGU -> eligibilityTe
        AppLanguage.ENGLISH -> eligibilityEn
    }

    fun getTtsScript(lang: AppLanguage): String {
        val typeStr = if (isCentral) {
            when (lang) {
                AppLanguage.HINDI -> "केंद्रीय सरकारी योजना"
                AppLanguage.TELUGU -> "కేంద్ర ప్రభుత్వ పథకం"
                AppLanguage.ENGLISH -> "Central Government Scheme"
            }
        } else {
            when (lang) {
                AppLanguage.HINDI -> "${stateName ?: ""} राज्य योजना"
                AppLanguage.TELUGU -> "${stateName ?: ""} రాష్ట్ర పథకం"
                AppLanguage.ENGLISH -> "${stateName ?: ""} State Scheme"
            }
        }
        return "${getName(lang)}. $typeStr. " +
                "${when (lang) {
                    AppLanguage.HINDI -> "लाभ: "
                    AppLanguage.TELUGU -> "ప్రయోజనం: "
                    AppLanguage.ENGLISH -> "Benefit: "
                }}${getBenefit(lang)}. " +
                "${when (lang) {
                    AppLanguage.HINDI -> "पात्रता: "
                    AppLanguage.TELUGU -> "అర్హత: "
                    AppLanguage.ENGLISH -> "Eligibility: "
                }}${getEligibility(lang)}."
    }
}
