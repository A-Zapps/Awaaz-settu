package com.example.data.model

import java.util.Locale

enum class AppLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val ttsLocale: Locale
) {
    HINDI(
        code = "hi",
        nativeName = "हिन्दी",
        englishName = "Hindi",
        ttsLocale = Locale("hi", "IN")
    ),
    TELUGU(
        code = "te",
        nativeName = "తెలుగు",
        englishName = "Telugu",
        ttsLocale = Locale("te", "IN")
    ),
    ENGLISH(
        code = "en",
        nativeName = "English",
        englishName = "English",
        ttsLocale = Locale("en", "IN")
    );

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.firstOrNull { it.code == code } ?: ENGLISH
        }
    }
}

data class LocalizedText(
    val en: String,
    val hi: String,
    val te: String
) {
    fun get(lang: AppLanguage): String = when (lang) {
        AppLanguage.HINDI -> hi
        AppLanguage.TELUGU -> te
        AppLanguage.ENGLISH -> en
    }
}
