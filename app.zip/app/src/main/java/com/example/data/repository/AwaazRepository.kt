package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.DocumentEntity
import com.example.data.local.GrievanceEntity
import com.example.data.local.ProfileEntity
import com.example.data.model.AppLanguage
import com.example.data.model.DocumentCategory
import com.example.data.model.DocumentItem
import com.example.data.model.GrievanceItem
import com.example.data.model.GrievanceStatus
import com.example.data.model.Scheme
import com.example.data.model.UserIntakeProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class AwaazRepository(private val dao: AppDao) {

    // Curated real official Welfare Schemes data for pilot districts
    val officialSchemes: List<Scheme> = listOf(
        Scheme(
            id = "pm_kisan",
            nameEn = "PM-KISAN Samman Nidhi",
            nameHi = "पीएम किसान सम्मान निधि",
            nameTe = "పీఎం కిసాన్ సమ్మాన్ నిధి",
            isCentral = true,
            stateName = null,
            category = "Agriculture",
            benefitEn = "₹6,000 per year directly into farmer bank accounts in 3 equal installments.",
            benefitHi = "किसानों के बैंक खातों में प्रति वर्ष ₹6,000 की प्रत्यक्ष वित्तीय सहायता।",
            benefitTe = "రైతుల బ్యాంక్ ఖాతాల్లో ఏటా ₹6,000 ఆర్థిక సహాయం 3 విడతల్లో జమ అవుతుంది.",
            eligibilityEn = "Small and marginal landholding farmer families in all states.",
            eligibilityHi = "सभी राज्यों में छोटे और सीमांत भूमिधारक किसान परिवार।",
            eligibilityTe = "అన్ని రాష్ట్రాల్లోని చిన్న మరియు సన్నకారు రైతు కుటుంబాలు.",
            applyUrl = "https://pmkisan.gov.in/",
            minAge = 18,
            maxAge = 100,
            targetGender = "ALL",
            allowedOccupations = listOf("FARMER", "DAILY_WAGE"),
            maxIncomeLakhs = 6.0
        ),
        Scheme(
            id = "rythu_bharosa",
            nameEn = "Rythu Bharosa / Rythu Bandhu",
            nameHi = "रैतु भरोसा (तेलंगाना/आंध्र)",
            nameTe = "రైతు భరోసా / రైతు బంధు (తెలంగాణ)",
            isCentral = false,
            stateName = "Telangana",
            category = "Agriculture",
            benefitEn = "₹10,000 to ₹15,000 per acre annual investment support for agriculture.",
            benefitHi = "कृषि निवेश के लिए प्रति एकड़ ₹10,000 से ₹15,000 वार्षिक सहायता।",
            benefitTe = "వ్యవసాయ పెట్టుబడి కొరకు ఎకరాకు ఏటా ₹10,000 నుండి ₹15,000 వరకు ఆర్థిక సహాయం.",
            eligibilityEn = "Resident farmers owning cultivable land in Telangana and partner districts.",
            eligibilityHi = "तेलंगाना और पायलट जिलों में कृषि योग्य भूमि रखने वाले किसान।",
            eligibilityTe = "తెలంగాణ మరియు పైలట్ జిల్లాల్లో సాగు భూమి కలిగిన రైతు కుటుంబాలు.",
            applyUrl = "https://rythubandhu.telangana.gov.in/",
            minAge = 18,
            maxAge = 100,
            targetGender = "ALL",
            allowedOccupations = listOf("FARMER"),
            maxIncomeLakhs = 8.0
        ),
        Scheme(
            id = "ayushman_bharat",
            nameEn = "Ayushman Bharat PM-JAY",
            nameHi = "आयुष्मान भारत प्रधानमंत्री जन आरोग्य योजना",
            nameTe = "ఆయుష్మాన్ భారత్ పీఎం-జేఏవై",
            isCentral = true,
            stateName = null,
            category = "Healthcare",
            benefitEn = "Free cashless health treatment coverage up to ₹5,00,000 per family per year.",
            benefitHi = "प्रति परिवार प्रति वर्ष ₹5,00,000 तक का मुफ्त कैशलेस स्वास्थ्य इलाज।",
            benefitTe = "కుటుంబానికి ఏడాదికి ₹5,00,000 వరకు ఉచిత క్యాష్‌లెస్ ఆరోగ్య చికిత్స.",
            eligibilityEn = "Low-income rural families and identified deprived households.",
            eligibilityHi = "कम आय वाले ग्रामीण परिवार और चिन्हित वंचित परिवार।",
            eligibilityTe = "తక్కువ ఆదాయం కలిగిన గ్రామీణ కుటుంబాలు మరియు అర్హులైన వర్గాలు.",
            applyUrl = "https://nha.gov.in/PM-JAY",
            minAge = 0,
            maxAge = 120,
            targetGender = "ALL",
            allowedOccupations = emptyList(),
            maxIncomeLakhs = 3.0
        ),
        Scheme(
            id = "pm_awas_rural",
            nameEn = "Pradhan Mantri Awas Yojana (Gramin)",
            nameHi = "प्रधानमंत्री आवास योजना (ग्रामीण)",
            nameTe = "ప్రధానమంత్రి ఆవాస్ యోజన (గ్రామీణ)",
            isCentral = true,
            stateName = null,
            category = "Housing",
            benefitEn = "Financial assistance of ₹1,20,000 to construct a durable pucca house.",
            benefitHi = "पक्का मकान बनाने के लिए ₹1,20,000 तक की वित्तीय सहायता।",
            benefitTe = "పక్కా ఇల్లు నిర్మించుకోవడానికి ₹1,20,000 ఆర్థిక సహాయం.",
            eligibilityEn = "Houseless families and those living in kutcha or dilapidated houses.",
            eligibilityHi = "बेघर परिवार और कच्चे या टूटे-फूटे घरों में रहने वाले लोग।",
            eligibilityTe = "ఇల్లు లేని వారు లేదా తాత్కాలిక గుడిసెల్లో నివసించే పేద కుటుంబాలు.",
            applyUrl = "https://pmayg.nic.in/",
            minAge = 18,
            maxAge = 120,
            targetGender = "ALL",
            allowedOccupations = emptyList(),
            maxIncomeLakhs = 2.5
        ),
        Scheme(
            id = "pm_svanidhi",
            nameEn = "PM SVANidhi Micro-Credit",
            nameHi = "पीएम स्वनिधि स्ट्रीट वेंडर ऋण योजना",
            nameTe = "పీఎం స్వనిధి వీధి వ్యాపారుల రుణం",
            isCentral = true,
            stateName = null,
            category = "Employment",
            benefitEn = "Collateral-free working capital loan starting at ₹10,000 up to ₹50,000 with 7% interest subsidy.",
            benefitHi = "सड़क किनारे रेहड़ी-पटरी विक्रेताओं के लिए ₹10,000 से ₹50,000 तक ब्याज सब्सिडी वाला ऋण।",
            benefitTe = "వీధి వ్యాపారులకు ₹10,000 నుండి ₹50,000 వరకు తక్కువ వడ్డీతో పూచీకత్తు లేని రుణం.",
            eligibilityEn = "Urban and peri-urban street vendors and small cart operators.",
            eligibilityHi = "शहरी और अर्ध-शहरी क्षेत्रों के रेहड़ी-पटरी व फेरीवाले।",
            eligibilityTe = "పట్టణ మరియు సెమీ-అర్బన్ ప్రాంతాల్లోని వీధి వ్యాపారులు.",
            applyUrl = "https://pmsvanidhi.mohua.gov.in/",
            minAge = 18,
            maxAge = 75,
            targetGender = "ALL",
            allowedOccupations = listOf("STREET_VENDOR", "DAILY_WAGE", "OTHER"),
            maxIncomeLakhs = 4.0
        ),
        Scheme(
            id = "mgnrega",
            nameEn = "MGNREGA Rural Employment Guarantee",
            nameHi = "मनरेगा ग्रामीण रोजगार गारंटी योजना",
            nameTe = "మహాత్మా గాంధీ ఉపాధి హామీ పథకం (నరేగా)",
            isCentral = true,
            stateName = null,
            category = "Employment",
            benefitEn = "Guaranteed 100 days of wage employment per year for rural households.",
            benefitHi = "ग्रामीण परिवारों को प्रति वर्ष कम से कम 100 दिनों के मजदूरी रोजगार की गारंटी।",
            benefitTe = "గ్రామీణ కుటుంబాలకు ఏటా 100 రోజుల వేతన ఉపాధి కల్పన హామీ.",
            eligibilityEn = "Any adult rural citizen willing to do unskilled manual work.",
            eligibilityHi = "ग्रामीण भारत का कोई भी वयस्क नागरिक जो अकुशल शारीरिक श्रम के लिए तैयार हो।",
            eligibilityTe = "గ్రామీణ ప్రాంతంలో శారీరక శ్రమ చేయడానికి సిద్ధంగా ఉన్న ఏ వయోజనుడైనా.",
            applyUrl = "https://nrega.nic.in/",
            minAge = 18,
            maxAge = 80,
            targetGender = "ALL",
            allowedOccupations = listOf("DAILY_WAGE", "FARMER", "UNEMPLOYED", "OTHER"),
            maxIncomeLakhs = 3.0
        ),
        Scheme(
            id = "mahalaxmi_telangana",
            nameEn = "Mahalaxmi Scheme (Free Bus & LPG)",
            nameHi = "महालक्ष्मी योजना (मुफ्त बस यात्रा और गैस सब्सिडी)",
            nameTe = "మహాలక్ష్మి పథకం (ఉచిత బస్సు & గ్యాస్ సబ్సిడీ)",
            isCentral = false,
            stateName = "Telangana",
            category = "Social Welfare",
            benefitEn = "Free RTC bus travel across the state and subsidized LPG cylinder at ₹500 for women.",
            benefitHi = "महिलाओं के लिए पूरे राज्य में मुफ्त बस यात्रा और ₹500 में रसोई गैस सिलेंडर।",
            benefitTe = "మహిళలకు రాష్ట్రవ్యాప్తంగా ఆర్టీసీ బస్సులలో ఉచిత ప్రయాణం మరియు ₹500 కే గ్యాస్ సిలిండర్.",
            eligibilityEn = "All resident women and girls residing in Telangana.",
            eligibilityHi = "तेलंगाना राज्य में रहने वाली सभी महिलाएं और बालिकाएं।",
            eligibilityTe = "తెలంగాణ రాష్ట్రంలో నివసించే మహిళలు మరియు బాలికలు.",
            applyUrl = "https://telangana.gov.in/",
            minAge = 10,
            maxAge = 100,
            targetGender = "FEMALE",
            allowedOccupations = emptyList(),
            maxIncomeLakhs = 10.0
        ),
        Scheme(
            id = "aasara_pension",
            nameEn = "Aasara Pension",
            nameHi = "आसरा सामाजिक सुरक्षा पेंशन",
            nameTe = "ఆసరా పింఛను పథకం",
            isCentral = false,
            stateName = "Telangana",
            category = "Social Welfare",
            benefitEn = "Monthly pension of ₹2,016 for elderly, widows, and disabled citizens.",
            benefitHi = "बुजुर्गों, विधवाओं और दिव्यांगों के लिए ₹2,016 प्रति माह सामाजिक सुरक्षा पेंशन।",
            benefitTe = "వృద్ధులు, వితంతువులు, దివ్యాంగులకు నెలకు ₹2,016 సామాజిక భద్రతా పింఛను.",
            eligibilityEn = "Senior citizens aged 57+, widows, and differently-abled individuals.",
            eligibilityHi = "57 वर्ष से अधिक आयु के वरिष्ठ नागरिक, विधवाएं और दिव्यांग नागरिक।",
            eligibilityTe = "57 ఏళ్లు పైబడిన వృద్ధులు, వితంతువులు మరియు దివ్యాంగులు.",
            applyUrl = "https://aasara.telangana.gov.in/",
            minAge = 57,
            maxAge = 120,
            targetGender = "ALL",
            allowedOccupations = emptyList(),
            maxIncomeLakhs = 2.0
        ),
        Scheme(
            id = "sukanya_samriddhi",
            nameEn = "Sukanya Samriddhi Yojana",
            nameHi = "सुकन्या समृद्धि योजना",
            nameTe = "సుకున్య సమృద్ధి యోజన",
            isCentral = true,
            stateName = null,
            category = "Social Welfare",
            benefitEn = "High-interest savings scheme with tax benefits for girl child education & future.",
            benefitHi = "बालिकाओं की शिक्षा और सुरक्षित भविष्य के लिए उच्च ब्याज वाली सरकारी बचत योजना।",
            benefitTe = "ఆడపిల్లల విద్య మరియు భవిష్యత్తు కోసం అధిక వడ్డీతో కూడిన ప్రభుత్వ పొదుపు పథకం.",
            eligibilityEn = "Parents/guardians of girl children below 10 years of age.",
            eligibilityHi = "10 वर्ष से कम उम्र की बालिकाओं के माता-पिता या अभिभावक।",
            eligibilityTe = "10 ఏళ్లలోపు వయసున్న ఆడపిల్లలు కలిగిన తల్లిదండ్రులు.",
            applyUrl = "https://www.india.gov.in/spotlight/sukanya-samriddhi-yojna",
            minAge = 0,
            maxAge = 10,
            targetGender = "FEMALE",
            allowedOccupations = emptyList(),
            maxIncomeLakhs = 15.0
        ),
        Scheme(
            id = "pre_matric_scholarship",
            nameEn = "National Pre-Matric Student Scholarship",
            nameHi = "राष्ट्रीय प्री-मैट्रिक छात्रवृत्ति योजना",
            nameTe = "నేషనల్ ప్రీ-మెట్రిక్ విద్యార్థి స్కాలర్‌షిప్",
            isCentral = true,
            stateName = null,
            category = "Education",
            benefitEn = "₹3,500 to ₹7,000 annual scholarship and book grant for school students in Classes 1 to 10.",
            benefitHi = "कक्षा 1 से 10 के स्कूली बच्चों के लिए ₹3,500 से ₹7,000 वार्षिक छात्रवृत्ति एवं पुस्तक अनुदान।",
            benefitTe = "1 నుండి 10వ తరగతి చదువుతున్న విద్యార్థులకు ఏటా ₹3,500 నుండి ₹7,000 వరకు స్కాలర్‌షిప్.",
            eligibilityEn = "School students under 18 years studying in recognized government/aided schools.",
            eligibilityHi = "मान्यता प्राप्त स्कूलों में पढ़ने वाले 18 वर्ष से कम आयु के छात्र-छात्राएं।",
            eligibilityTe = "గుర్తింపు పొందిన పాఠశాలల్లో చదువుతున్న 18 ఏళ్లలోపు విద్యార్థులు.",
            applyUrl = "https://scholarships.gov.in/",
            minAge = 5,
            maxAge = 18,
            targetGender = "ALL",
            allowedOccupations = listOf("STUDENT", "OTHER", "UNEMPLOYED"),
            maxIncomeLakhs = 2.5
        ),
        Scheme(
            id = "pm_poshan",
            nameEn = "PM POSHAN / Mid-Day Meal Scheme",
            nameHi = "पीएम पोषण (मध्याह्न भोजन एवं पोषण योजना)",
            nameTe = "పీఎం పోషణ్ / మధ్యాహ్న భోజన పథకం",
            isCentral = true,
            stateName = null,
            category = "Education",
            benefitEn = "Free hot nutritious meals, iron-folic supplements, and growth monitoring for children.",
            benefitHi = "स्कूली बच्चों के लिए मुफ्त गर्म पौष्टिक मध्याह्न भोजन और स्वास्थ्य पूरक।",
            benefitTe = "పాఠశాల పిల్లలకు ఉచిత పౌష్టికాహార మధ్యాహ్న భోజనం మరియు పోషక మద్దతు.",
            eligibilityEn = "All children aged 3 to 15 enrolled in primary and upper primary schools.",
            eligibilityHi = "प्राथमिक और उच्च प्राथमिक विद्यालयों में नामांकित 3 से 15 वर्ष के बच्चे।",
            eligibilityTe = "ప్రాథమిక మరియు ఉన్నత ప్రాథమిక పాఠశాలల్లో చదువుతున్న 3 నుండి 15 సంవత్సరాల పిల్లలు.",
            applyUrl = "https://pmposhan.education.gov.in/",
            minAge = 3,
            maxAge = 15,
            targetGender = "ALL",
            allowedOccupations = emptyList(),
            maxIncomeLakhs = 8.0
        ),
        Scheme(
            id = "balika_samriddhi",
            nameEn = "Balika Samriddhi Yojana (Girl Child Grant)",
            nameHi = "बालिका समृद्धि योजना (बालिका विकास अनुदान)",
            nameTe = "బాలికా సమృద్ధి యోజన (ఆడపిల్లల రక్షణ)",
            isCentral = true,
            stateName = null,
            category = "Social Welfare",
            benefitEn = "₹500 post-birth financial grant plus annual scholarships up to ₹1,000 for girl child education.",
            benefitHi = "जन्म के समय ₹500 का अनुदान तथा स्कूल में प्रत्येक कक्षा उत्तीर्ण करने पर वार्षिक छात्रवृत्ति।",
            benefitTe = "పుట్టినప్పుడు ₹500 ఆర్థిక సహాయం మరియు పాఠశాల విద్య కోసం వార్షిక స్కాలర్‌షిప్‌లు.",
            eligibilityEn = "Girl children born in low-income families below 18 years of age.",
            eligibilityHi = "बीपीएल परिवारों में जन्मी 18 वर्ष से कम आयु की बालिकाएं।",
            eligibilityTe = "పేద కుటుంబాల్లోని 18 ఏళ్లలోపు బాలికలు.",
            applyUrl = "https://wcd.nic.in/",
            minAge = 0,
            maxAge = 18,
            targetGender = "FEMALE",
            allowedOccupations = emptyList(),
            maxIncomeLakhs = 2.0
        )
    )

    fun getMatchedSchemes(profile: UserIntakeProfile): List<Scheme> {
        return officialSchemes.filter { scheme ->
            // Age match (if age > 0)
            val ageMatch = if (profile.age > 0) {
                profile.age in scheme.minAge..scheme.maxAge
            } else true

            // Gender match
            val genderMatch = scheme.targetGender == "ALL" ||
                    scheme.targetGender.equals(profile.gender, ignoreCase = true)

            // State match
            val stateMatch = scheme.isCentral ||
                    scheme.stateName.isNullOrEmpty() ||
                    scheme.stateName.equals(profile.state, ignoreCase = true) ||
                    profile.state == "All India"

            // Income match
            val incomeMatch = profile.incomeRangeLakhs <= scheme.maxIncomeLakhs

            ageMatch && genderMatch && stateMatch && incomeMatch
        }
    }

    // Grievances Flow
    val allGrievances: Flow<List<GrievanceItem>> = dao.getAllGrievances().map { list ->
        list.map { it.toItem() }
    }

    suspend fun submitGrievance(
        schemeId: String?,
        schemeName: String,
        category: String,
        description: String,
        isVoice: Boolean,
        citizenName: String,
        citizenPhone: String,
        state: String,
        isOnline: Boolean
    ): GrievanceItem {
        val randomNum = Random.nextInt(1000, 9999)
        val tracking = "AS-${SimpleDateFormat("yyyy", Locale.US).format(Date())}-$randomNum"

        val item = GrievanceItem(
            id = 0,
            trackingNumber = tracking,
            schemeId = schemeId,
            schemeName = schemeName,
            category = category,
            description = description,
            isVoiceRecorded = isVoice,
            citizenName = citizenName.ifBlank { "Citizen" },
            citizenPhone = citizenPhone.ifBlank { "9876543210" },
            state = state,
            status = GrievanceStatus.SUBMITTED,
            officerRemarks = "Grievance received and registered under pilot district nodal cell.",
            createdAt = System.currentTimeMillis(),
            isSynced = isOnline
        )

        val rowId = dao.insertGrievance(GrievanceEntity.fromItem(item))
        return item.copy(id = rowId)
    }

    suspend fun updateGrievanceStatusByAdmin(id: Long, newStatus: GrievanceStatus, remarks: String) {
        dao.updateGrievanceStatus(id, newStatus.name, remarks)
    }

    suspend fun syncOfflineGrievances() {
        val unsynced = dao.getUnsyncedGrievances()
        for (item in unsynced) {
            dao.updateGrievance(item.copy(isSynced = true))
        }
    }

    // Documents Flow
    val allDocuments: Flow<List<DocumentItem>> = dao.getAllDocuments().map { list ->
        list.map { it.toItem() }
    }

    suspend fun addDocument(
        title: String,
        category: DocumentCategory,
        fileName: String,
        fileSizeKb: Int
    ): Long {
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val dateStr = dateFormat.format(Date())
        val entity = DocumentEntity(
            title = title,
            category = category.name,
            fileName = fileName,
            uploadDate = dateStr,
            fileSizeKb = fileSizeKb,
            retentionDaysRemaining = 365,
            isEncrypted = true
        )
        return dao.insertDocument(entity)
    }

    suspend fun deleteDocument(id: Long) {
        dao.deleteDocumentById(id)
    }

    // User Profile Flow
    val userProfile: Flow<UserIntakeProfile?> = dao.getProfileFlow().map { it?.toProfile() }

    suspend fun saveUserProfile(profile: UserIntakeProfile) {
        dao.saveProfile(ProfileEntity.fromProfile(profile))
    }

    suspend fun deleteMyData() {
        dao.clearAllGrievances()
        dao.clearAllDocuments()
        dao.clearProfile()
    }

    suspend fun seedInitialDataIfEmpty() {
        val currentProfile = dao.getProfile()
        if (currentProfile == null) {
            // Seed a default citizen profile
            dao.saveProfile(
                ProfileEntity(
                    id = 1,
                    isForSelf = true,
                    beneficiaryName = "Ramesh Rao",
                    age = 42,
                    gender = "MALE",
                    state = "Telangana",
                    occupation = "FARMER",
                    incomeRangeLakhs = 1.5,
                    languageCode = "en",
                    lastUpdated = System.currentTimeMillis()
                )
            )

            // Seed 2 default documents in My Documents
            dao.insertDocument(
                DocumentEntity(
                    title = "Ration Card (NFSA Pink Card)",
                    category = DocumentCategory.IDENTITY_PROOF.name,
                    fileName = "ration_card_verified.pdf",
                    uploadDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                    fileSizeKb = 342,
                    retentionDaysRemaining = 360,
                    isEncrypted = true
                )
            )
            dao.insertDocument(
                DocumentEntity(
                    title = "Tahsildar Income Certificate",
                    category = DocumentCategory.INCOME_CERTIFICATE.name,
                    fileName = "income_cert_2026.pdf",
                    uploadDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                    fileSizeKb = 512,
                    retentionDaysRemaining = 345,
                    isEncrypted = true
                )
            )

            // Seed 1 default sample grievance
            dao.insertGrievance(
                GrievanceEntity(
                    trackingNumber = "AS-2026-4821",
                    schemeId = "rythu_bharosa",
                    schemeName = "Rythu Bharosa / Rythu Bandhu",
                    category = "Subsidy Delay",
                    description = "Installment for Rabi season not credited to SBI account.",
                    isVoiceRecorded = true,
                    citizenName = "Ramesh Rao",
                    citizenPhone = "9848022334",
                    state = "Telangana",
                    status = GrievanceStatus.IN_PROGRESS.name,
                    officerRemarks = "Verification completed at Mandal Agriculture Office. Bank account IFSC updated.",
                    createdAt = System.currentTimeMillis() - 86400000L * 3,
                    isSynced = true
                )
            )
        }
    }
}
