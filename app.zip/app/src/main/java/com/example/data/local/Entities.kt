package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DocumentCategory
import com.example.data.model.GrievanceItem
import com.example.data.model.GrievanceStatus
import com.example.data.model.DocumentItem
import com.example.data.model.UserIntakeProfile

@Entity(tableName = "grievances")
data class GrievanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackingNumber: String,
    val schemeId: String?,
    val schemeName: String,
    val category: String,
    val description: String,
    val isVoiceRecorded: Boolean,
    val citizenName: String,
    val citizenPhone: String,
    val state: String,
    val status: String,
    val officerRemarks: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = true
) {
    fun toItem(): GrievanceItem = GrievanceItem(
        id = id,
        trackingNumber = trackingNumber,
        schemeId = schemeId,
        schemeName = schemeName,
        category = category,
        description = description,
        isVoiceRecorded = isVoiceRecorded,
        citizenName = citizenName,
        citizenPhone = citizenPhone,
        state = state,
        status = runCatching { GrievanceStatus.valueOf(status) }.getOrDefault(GrievanceStatus.SUBMITTED),
        officerRemarks = officerRemarks,
        createdAt = createdAt,
        isSynced = isSynced
    )

    companion object {
        fun fromItem(item: GrievanceItem): GrievanceEntity = GrievanceEntity(
            id = item.id,
            trackingNumber = item.trackingNumber,
            schemeId = item.schemeId,
            schemeName = item.schemeName,
            category = item.category,
            description = item.description,
            isVoiceRecorded = item.isVoiceRecorded,
            citizenName = item.citizenName,
            citizenPhone = item.citizenPhone,
            state = item.state,
            status = item.status.name,
            officerRemarks = item.officerRemarks,
            createdAt = item.createdAt,
            isSynced = item.isSynced
        )
    }
}

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val fileName: String,
    val uploadDate: String,
    val fileSizeKb: Int,
    val retentionDaysRemaining: Int = 365,
    val isEncrypted: Boolean = true
) {
    fun toItem(): DocumentItem = DocumentItem(
        id = id,
        title = title,
        category = runCatching { DocumentCategory.valueOf(category) }.getOrDefault(DocumentCategory.IDENTITY_PROOF),
        fileName = fileName,
        uploadDate = uploadDate,
        fileSizeKb = fileSizeKb,
        retentionDaysRemaining = retentionDaysRemaining,
        isEncrypted = isEncrypted
    )

    companion object {
        fun fromItem(item: DocumentItem): DocumentEntity = DocumentEntity(
            id = item.id,
            title = item.title,
            category = item.category.name,
            fileName = item.fileName,
            uploadDate = item.uploadDate,
            fileSizeKb = item.fileSizeKb,
            retentionDaysRemaining = item.retentionDaysRemaining,
            isEncrypted = item.isEncrypted
        )
    }
}

@Entity(tableName = "user_profile")
data class ProfileEntity(
    @PrimaryKey val id: Long = 1,
    val isForSelf: Boolean = true,
    val beneficiaryName: String = "",
    val age: Int = 0,
    val gender: String = "MALE",
    val state: String = "Telangana",
    val occupation: String = "FARMER",
    val incomeRangeLakhs: Double = 1.0,
    val languageCode: String = "en",
    val lastUpdated: Long = System.currentTimeMillis()
) {
    fun toProfile(): UserIntakeProfile = UserIntakeProfile(
        id = id,
        isForSelf = isForSelf,
        beneficiaryName = beneficiaryName,
        age = age,
        gender = gender,
        state = state,
        occupation = occupation,
        incomeRangeLakhs = incomeRangeLakhs,
        languageCode = languageCode,
        lastUpdated = lastUpdated
    )

    companion object {
        fun fromProfile(p: UserIntakeProfile): ProfileEntity = ProfileEntity(
            id = p.id,
            isForSelf = p.isForSelf,
            beneficiaryName = p.beneficiaryName,
            age = p.age,
            gender = p.gender,
            state = p.state,
            occupation = p.occupation,
            incomeRangeLakhs = p.incomeRangeLakhs,
            languageCode = p.languageCode,
            lastUpdated = p.lastUpdated
        )
    }
}
