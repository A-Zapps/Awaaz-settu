package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Grievances
    @Query("SELECT * FROM grievances ORDER BY createdAt DESC")
    fun getAllGrievances(): Flow<List<GrievanceEntity>>

    @Query("SELECT * FROM grievances WHERE isSynced = 0")
    suspend fun getUnsyncedGrievances(): List<GrievanceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrievance(grievance: GrievanceEntity): Long

    @Update
    suspend fun updateGrievance(grievance: GrievanceEntity)

    @Query("UPDATE grievances SET status = :newStatus, officerRemarks = :remarks WHERE id = :id")
    suspend fun updateGrievanceStatus(id: Long, newStatus: String, remarks: String)

    @Query("DELETE FROM grievances WHERE id = :id")
    suspend fun deleteGrievanceById(id: Long)

    @Query("DELETE FROM grievances")
    suspend fun clearAllGrievances()

    // Documents
    @Query("SELECT * FROM documents ORDER BY id DESC")
    fun getAllDocuments(): Flow<List<DocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: DocumentEntity): Long

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deleteDocumentById(id: Long)

    @Query("DELETE FROM documents")
    suspend fun clearAllDocuments()

    // Profile
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getProfileFlow(): Flow<ProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfile(): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: ProfileEntity)

    @Query("DELETE FROM user_profile")
    suspend fun clearProfile()
}
