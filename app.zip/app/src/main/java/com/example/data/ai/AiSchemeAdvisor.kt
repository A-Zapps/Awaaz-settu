package com.example.data.ai

import com.example.BuildConfig
import com.example.data.model.AppLanguage
import com.example.data.model.Scheme
import com.example.data.model.UserIntakeProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object AiSchemeAdvisor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateStepsToApply(
        scheme: Scheme,
        language: AppLanguage,
        profile: UserIntakeProfile
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (!apiKey.isNullOrBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val promptText = """
                    You are an official Indian Citizen Welfare Scheme Application Guide.
                    Provide exact step-by-step instructions on how a citizen (${profile.age} years old, state: ${profile.state}) should apply for the scheme "${scheme.nameEn}" (${scheme.category}).
                    
                    Respond in ${when (language) {
                        AppLanguage.HINDI -> "Hindi (हिंदी)"
                        AppLanguage.TELUGU -> "Telugu (తెలుగు)"
                        AppLanguage.ENGLISH -> "English"
                    }}.
                    
                    STRICT FORMAT MANDATE:
                    Format the entire output strictly with steps formatted as:
                    step 1:
                    <step 1 explanation>
                    step 2:
                    <step 2 explanation>
                    step 3:
                    <step 3 explanation>
                    step 4:
                    end
                    
                    Make sure to explicitly write "step 1:", "step 2:", "step 3:", and finish with "step 4:\nend".
                    Keep each step concise, clear, and actionable (mentioning required documents and official portal ${scheme.applyUrl} or local CSC/Mandal office).
                """.trimIndent()

                val jsonPayload = JSONObject().apply {
                    val contentsArr = JSONArray().apply {
                        val contentObj = JSONObject().apply {
                            val partsArr = JSONArray().apply {
                                val partObj = JSONObject().apply {
                                    put("text", promptText)
                                }
                                put(partObj)
                            }
                            put("parts", partsArr)
                        }
                        put(contentObj)
                    }
                    put("contents", contentsArr)
                }

                val mediaType = "application/json".toMediaType()
                val requestBody = jsonPayload.toString().toRequestBody(mediaType)
                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val bodyString = response.body?.string()
                    if (!bodyString.isNullOrBlank()) {
                        val json = JSONObject(bodyString)
                        val candidates = json.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val parts = content?.optJSONArray("parts")
                            if (parts != null && parts.length() > 0) {
                                val text = parts.getJSONObject(0).optString("text")
                                if (text.isNotBlank()) {
                                    return@withContext text.trim()
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Fallback to verified local steps
            }
        }

        getPredefinedSteps(scheme, language, profile)
    }

    fun getPredefinedSteps(
        scheme: Scheme,
        language: AppLanguage,
        profile: UserIntakeProfile
    ): String {
        return when (language) {
            AppLanguage.HINDI -> getStepsHindi(scheme, profile)
            AppLanguage.TELUGU -> getStepsTelugu(scheme, profile)
            AppLanguage.ENGLISH -> getStepsEnglish(scheme, profile)
        }
    }

    private fun getStepsEnglish(scheme: Scheme, profile: UserIntakeProfile): String {
        return when (scheme.id) {
            "pm_kisan" -> """
step 1:
Gather your Aadhaar Card, Land Record documents (Pattadar Passbook / RoR 7/12), and active Aadhaar-linked Bank Account Passbook.

step 2:
Visit your nearest Common Service Centre (CSC / MeeSeva) or open the official portal at https://pmkisan.gov.in/ and select 'New Farmer Registration'.

step 3:
Enter your 12-digit Aadhaar number, complete OTP verification, submit land survey details, and collect your application acknowledgment number.

step 4:
end
""".trimIndent()

            "rythu_bharosa" -> """
step 1:
Confirm that your agricultural land records and Pattadar Passbook details are updated on the state Dharani / Revenue portal.

step 2:
Meet your Village Agriculture Extension Officer (AEO) or visit the Mandal Agriculture Office with your Aadhaar and bank details.

step 3:
Verify your active bank account IFSC details for direct DBT seasonal input assistance prior to the sowing season.

step 4:
end
""".trimIndent()

            "ayushman_bharat" -> """
step 1:
Keep your NFSA Pink/White Ration Card and Aadhaar cards of all family members ready.

step 2:
Visit the Ayushman Mitra helpdesk at any empaneled Government or Private Hospital, or your nearest CSC / MeeSeva center.

step 3:
Complete biometric fingerprint/OTP e-KYC verification to instantly generate and download your Ayushman Card for ₹5 Lakh cashless treatment.

step 4:
end
""".trimIndent()

            "pm_svanidhi" -> """
step 1:
Collect your Street Vendor Certificate / Letter of Recommendation (LoR) from your Urban Local Body or Municipality.

step 2:
Apply online at https://pmsvanidhi.mohua.gov.in/ or through your nearest public sector bank branch or Common Service Center.

step 3:
Upload Aadhaar and bank passbook to receive direct working capital loan disbursement with 7% interest subsidy.

step 4:
end
""".trimIndent()

            "pm_awas_rural" -> """
step 1:
Verify your household inclusion in the Gram Sabha SECC priority list with your Gram Panchayat Secretary.

step 2:
Submit Aadhaar, MGNREGA Job Card, Bank Account details, and geo-tagged photographs of your existing kutcha house.

step 3:
Once sanctioned, house construction financial assistance is credited directly in 3 stage-wise installments into your bank account.

step 4:
end
""".trimIndent()

            "mgnrega" -> """
step 1:
Visit your Gram Panchayat office and submit an application with photographs and Aadhaar cards of adult household members.

step 2:
Receive your official MGNREGA Job Card within 15 days from the Gram Panchayat.

step 3:
Submit a written work request at the Panchayat to receive guaranteed wage employment work allocation within 15 days.

step 4:
end
""".trimIndent()

            "mahalaxmi_telangana" -> """
step 1:
Carry your valid government photo ID / Aadhaar card proving Telangana residency for free RTC bus travel.

step 2:
For the ₹500 LPG cylinder subsidy, submit your Praja Palana application acknowledgment and white ration card at the Mandal office.

step 3:
Subsidy amount is directly credited to your Aadhaar-linked bank account on every monthly gas cylinder refill.

step 4:
end
""".trimIndent()

            else -> """
step 1:
Gather your primary identification documents (Aadhaar Card, Ration Card, Income Certificate, and active Bank Passbook).

step 2:
Visit the nearest CSC / MeeSeva / Gram Panchayat center or open the official portal at ${scheme.applyUrl}.

step 3:
Fill the application form, complete biometric/OTP e-KYC verification, and retain the acknowledgment tracking receipt.

step 4:
end
""".trimIndent()
        }
    }

    private fun getStepsHindi(scheme: Scheme, profile: UserIntakeProfile): String {
        return when (scheme.id) {
            "pm_kisan" -> """
step 1:
अपना आधार कार्ड, भूमि के दस्तावेज़ (खसरा/खतौनी/पट्टा) और आधार से लिंक बैंक पासबुक तैयार रखें।

step 2:
नजदीकी सीएससी (CSC) केंद्र जाएं या आधिकारिक पोर्टल https://pmkisan.gov.in/ पर 'New Farmer Registration' पर क्लिक करें।

step 3:
आधार नंबर दर्ज कर ओटीपी सत्यापन करें, भूमि का विवरण भरें और पावती रसीद प्राप्त करें।

step 4:
end
""".trimIndent()

            "rythu_bharosa" -> """
step 1:
अपनी पट्टादार पासबुक और आधार कार्ड का विवरण धरणी/राजस्व पोर्टल पर अद्यतित रखें।

step 2:
अपने ग्राम कृषि विस्तार अधिकारी (AEO) या मंडल कृषि कार्यालय में जाकर आवश्यक फॉर्म भरें।

step 3:
फसल बुवाई से पहले प्रत्यक्ष बैंक खाते (DBT) में राशि प्राप्त करने के लिए बैंक विवरण सत्यापित कराएं।

step 4:
end
""".trimIndent()

            "ayushman_bharat" -> """
step 1:
राशन कार्ड और परिवार के सभी सदस्यों के आधार कार्ड एकत्र करें।

step 2:
सूचीबद्ध सरकारी/निजी अस्पताल के आयुष्मान मित्र केंद्र या नजदीकी जन सेवा केंद्र (CSC) पर जाएं।

step 3:
बायोमेट्रिक ई-केवाईसी पूर्ण करके ₹5 लाख का मुफ्त कैशलेस आयुष्मान कार्ड प्राप्त करें।

step 4:
end
""".trimIndent()

            "pm_svanidhi" -> """
step 1:
नगर पालिका / शहरी निकाय से वेंडर प्रमाण पत्र या सिफारिश पत्र (LoR) प्राप्त करें।

step 2:
आधिकारिक पोर्टल https://pmsvanidhi.mohua.gov.in/ या नजदीकी बैंक शाखा के माध्यम से आवेदन करें।

step 3:
आधार और बैंक विवरण अपलोड करके बिना किसी गारंटी के 7% ब्याज सब्सिडी वाला ऋण प्राप्त करें।

step 4:
end
""".trimIndent()

            else -> """
step 1:
आवश्यक दस्तावेज़ (आधार कार्ड, आय प्रमाण पत्र, राशन कार्ड एवं बैंक पासबुक) एकत्रित करें।

step 2:
नजदीकी जन सेवा केंद्र (CSC/MeeSeva) या आधिकारिक पोर्टल ${scheme.applyUrl} पर जाएं।

step 3:
आवेदन पत्र भरकर ई-केवाईसी पूरा करें और आवेदन पावती संख्या प्राप्त करें।

step 4:
end
""".trimIndent()
        }
    }

    private fun getStepsTelugu(scheme: Scheme, profile: UserIntakeProfile): String {
        return when (scheme.id) {
            "pm_kisan" -> """
step 1:
మీ ఆధార్ కార్డ్, పట్టాదారు పాస్‌బుక్ / భూమి రికార్డులు మరియు ఆధార్‌తో లింక్ చేయబడిన బ్యాంక్ పాస్‌బుక్ సిద్ధంగా ఉంచుకోండి.

step 2:
సమీప మీసేవ / CSC కేంద్రాన్ని సందర్శించండి లేదా https://pmkisan.gov.in/ పోర్టల్‌లో 'New Farmer Registration' ఎంచుకోండి.

step 3:
ఆధార్ నంబర్ నమోదు చేసి OTP వెరిఫికేషన్ పూర్తి చేసి భూమి వివరాలు నమోదు చేసి రసీదు పొందండి.

step 4:
end
""".trimIndent()

            "rythu_bharosa" -> """
step 1:
మీ పట్టాదారు పాస్‌బుక్ మరియు ఆధార్ వివరాలను ధరణి రికార్డులలో సరిచూసుకోండి.

step 2:
గ్రామ వ్యవసాయ విస్తరణ అధికారి (AEO)ని లేదా మండల వ్యవసాయ కార్యాలయాన్ని సంప్రదించండి.

step 3:
సాగు సీజన్‌కు ముందు పెట్టుబడి సాయం నేరుగా బ్యాంక్ ఖాతాలో జమ కావడానికి బ్యాంక్ వివరాలు నిర్ధారించండి.

step 4:
end
""".trimIndent()

            "ayushman_bharat" -> """
step 1:
రేషన్ కార్డ్ మరియు కుటుంబ సభ్యులందరి ఆధార్ కార్డులను సిద్ధం చేసుకోండి.

step 2:
గుర్తింపు పొందిన ఆసుపత్రిలోని ఆయుష్మాన్ మిత్ర వద్దకు లేదా మీసేవ కేంద్రానికి వెళ్ళండి.

step 3:
బయోమెట్రిక్ e-KYC పూర్తి చేసి ₹5 లక్షల ఉచిత చికిత్స కోసం ఆయుష్మాన్ గోల్డెన్ కార్డ్ పొందండి.

step 4:
end
""".trimIndent()

            else -> """
step 1:
అవసరమైన పత్రాలు (ఆధార్ కార్డ్, రేషన్ కార్డ్, ఆదాయ ధ్రువీకరణ పత్రం, బ్యాంక్ పాస్‌బుక్) సిద్ధం చేసుకోండి.

step 2:
సమీప మీసేవ కేంద్రం లేదా అధికారిక పోర్టల్ ${scheme.applyUrl} ద్వారా దరఖాస్తు చేయండి.

step 3:
దరఖాస్తు సమర్పించి e-KYC పూర్తి చేసి రసీదు నంబర్‌ను భద్రపరుచుకోండి.

step 4:
end
""".trimIndent()
        }
    }
}
